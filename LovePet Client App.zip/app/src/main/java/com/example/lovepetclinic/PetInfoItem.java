package com.example.lovepetclinic;

public class PetInfoItem {
	private String id;
	private String pet_name;
	private String age;
	private String type; 
	private String detail;
	private String sex; 
	private String specific;
	
	
	//getter setter
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPet_name() {
		return pet_name;
	}
	public void setPet_name(String pet_name) {
		this.pet_name = pet_name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getSpecific() {
		return specific;
	}
	public void setSpecific(String specific) {
		this.specific = specific;
	}
	
	public PetInfoItem(){}
	public PetInfoItem(String id, String pet_name, String age, String type, String sex, String detail,String specific){
		this.id = id;
		this.pet_name = pet_name;
		this.age = age;
		this.type = type;
		this.sex = sex;
		this.detail = detail;
		this.specific=specific;
	}
	
}
