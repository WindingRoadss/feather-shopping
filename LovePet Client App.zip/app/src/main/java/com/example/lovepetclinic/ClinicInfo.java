package com.example.lovepetclinic;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;

import com.example.lovepetclinic.ConnectDB;
import com.example.lovepetclinic.R;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ClinicInfo extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.clinic_info);

		ActionBar actionBar = getActionBar();
		actionBar.hide();
		
//		Button btnCancel = (Button) findViewById(R.id.cancelBtn);
//		btnCancel.setOnClickListener(new OnClickListener() {
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				finish();
//			}
//		});

	}
}
