package com.example.lovepetclinic;

public class ReservationViewItem1 {
	private String id;
	private String year;
	private String month;
	private String day;
	private String time;
	private String pet_name;
	private String detail;
	
	//constructor
	public ReservationViewItem1(String id,String year,String month,String day,String time,String pet_name,String detail){
		this.id=id;
		this.year=year;
		this.month=month;
		this.day=day;
		this.time=time;
		this.pet_name=pet_name;
		this.detail=detail;
	}
	
	//getter setter
	public String getId(){
		return id;
	}
	public void setId(String id){
		this.id=id;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getPet_name() {
		return pet_name;
	}
	public void setPet_name(String pet_name) {
		this.pet_name = pet_name;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	
}
