package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

//ȣ��-���ι�ư��ġ ��
public class ReservationConfirmHpt extends Activity {
	Bundle bundle = new Bundle();
	String id = ConnectDB.getId();
	String year, month, day, time, pet_name, user_name, detail;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		ConnectDB.addActList(this); // Activity �߰�
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.reservation_confirm_hpt);//xml���� �̸�

		bundle = getIntent().getExtras();
		year = bundle.getString("year");
		month = bundle.getString("month");
		day = bundle.getString("day");
		time = bundle.getString("time");
		pet_name = bundle.getString("pet_name");
		user_name = bundle.getString("user_name");
		detail = bundle.getString("detail");
		
		
		Button btn1 = (Button)findViewById(R.id.okBtn);//xml���� ok��ưid
		btn1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// delete operation
				
				////
				if(ConnectDB.isNetworkAvailable()) {
					Dialog mProgress=new Dialog(ReservationConfirmHpt.this,R.style.MyDialog);
					mProgress.setCancelable(true);
					mProgress.addContentView(new ProgressBar(ReservationConfirmHpt.this),
											new LayoutParams(LayoutParams.WRAP_CONTENT,
															LayoutParams.WRAP_CONTENT));
					mProgress.show();
					try {
						if(ConnectDB.getPetNumberAvailable()){
							ArrayList<String> result=ConnectDB.reserveHospital(year, month, day, time, 
									pet_name, id, user_name, detail);
							if(result.get(0).equals("FIN")){
								Toast.makeText(getBaseContext(),"������ �Ϸ�Ǿ����ϴ�\n������Ȳ���� Ȯ�����ּ���", Toast.LENGTH_LONG).show();
								finish();
							}
							else if(result.get(0).equals("NO"))
								Toast.makeText(getBaseContext(),"������ �����Ͽ����ϴ�", Toast.LENGTH_LONG).show();
							else
								Toast.makeText(getBaseContext(),"ERROR : DB result error", Toast.LENGTH_LONG).show();
						}else
							Toast.makeText(getBaseContext(), "������ �߰����ּ���", Toast.LENGTH_SHORT).show();
					} catch (ClientProtocolException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					mProgress.dismiss();
					Intent intent = new Intent(getBaseContext(), Reservation.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}	
        });
		
		Button btn2 = (Button)findViewById(R.id.cancelBtn);//cancel btn
		btn2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();		
			}	
        });
	}

	
}
