package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

//ȣ��-���ι�ư��ġ ��
public class ReservationView2DeletePopup extends Activity {
	Bundle bundle = new Bundle();
	String id = ConnectDB.getId();
	String pet_name;
    String in_year;
    String in_month;
    String in_day;
    String out_year;
    String out_month;
    String out_day;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		ConnectDB.addActList(this); // Activity �߰�
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.reservation_view2_delete_popup);//xml���� �̸�

		bundle = getIntent().getExtras();
		pet_name = bundle.getString("pet_name");
		in_year = bundle.getString("in_year");
		in_month = bundle.getString("in_month");
		in_day = bundle.getString("in_day");
		out_year = bundle.getString("out_year");
		out_month = bundle.getString("out_month");
		out_day = bundle.getString("out_day");
		
		Button btn1 = (Button)findViewById(R.id.okBtn);//xml���� ok��ưid
		btn1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// delete operation
				if(ConnectDB.isNetworkAvailable()) {
					Dialog mProgress=new Dialog(ReservationView2DeletePopup.this,R.style.MyDialog);
					mProgress.setCancelable(true);
					mProgress.addContentView(new ProgressBar(ReservationView2DeletePopup.this),
											new LayoutParams(LayoutParams.WRAP_CONTENT,
															LayoutParams.WRAP_CONTENT));
					mProgress.show();
					try {
						ArrayList<String> result=ConnectDB.deleteRsvHtl(id, pet_name, in_year, in_month,
								in_day, out_year, out_month, out_day);
						
						if(result.get(0).equals("FIN"))
							Toast.makeText(getBaseContext(), "�����Ǿ����ϴ�.", 
									Toast.LENGTH_SHORT).show();
						else 
							Toast.makeText(getBaseContext(), "ERROR : deleteRsvHtl", 
									Toast.LENGTH_SHORT).show();
						finish();
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}		
					mProgress.dismiss();
					Intent intent = new Intent(getBaseContext(), ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
					finish();
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
							 Toast.LENGTH_SHORT).show();
			}	
        });
		
		Button btn2 = (Button)findViewById(R.id.cancelBtn);//cancel btn
		btn2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();		
			}	
        });
	}

	
}
