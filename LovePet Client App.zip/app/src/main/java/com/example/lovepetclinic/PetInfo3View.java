package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class PetInfo3View extends AniListenerActivity {

	String id=ConnectDB.getId();
	String string_pet_name;
	Bundle bundle;
	
	public void onBackPressed() { 
		if(sliding_menu.onBackFunction() == 0) { // ���̵� �޴��� ��Ÿ�� ���� ���� ���¸� finish
			finish();
		}
	}
	
	/* sliding menu�� �̸��� �̸��� ���� */
	private String str_user_name = ConnectDB.getUserName();
	private String str_email = ConnectDB.getUserEmail();
	/* sliding menu�� �̸��� �̸��� ���� */
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		
		setContentView(R.layout.pet_info3_view);
		
		ConnectDB.addActList(this); // Activity �߰�
		
		/* Sliding Menu options */
		sliding_menu = new SlidingMenu(this);
		sliding_menu.setMenu(findViewById(R.id.menu));
		sliding_menu.setMainView(findViewById(R.id.mainView));
		/* Sliding Menu options */
		
		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_petinfo_getinfo_bar); 
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		
		/* userName and userEmail Setting  */
		TextView userName = (TextView)findViewById(R.id.userName);
		Log.d("setTextTest", "str_user_name" + str_user_name);
		userName.setText(str_user_name);
		TextView userEmail = (TextView)findViewById(R.id.userEmail);
		userEmail.setText(str_email);
		/* userName and userEmail Setting  */
		
		
		
		TextView pet_name=(TextView)findViewById(R.id.petNameTextView);
		TextView age=(TextView)findViewById(R.id.ageTextView);
		TextView kind=(TextView)findViewById(R.id.kindTextView);
		TextView kind_detail=(TextView)findViewById(R.id.kindDetailTextView);
		TextView sex=(TextView)findViewById(R.id.sexTextView);
		TextView specific=(TextView)findViewById(R.id.specificTextView); 
		Button cancel =(Button)findViewById(R.id.cancelBtn);

		bundle= getIntent().getExtras();
		string_pet_name=bundle.getString("pet_name");
		
		//progress
		Dialog mProgress=new Dialog(PetInfo3View.this,R.style.MyDialog);
		mProgress.setCancelable(true);
		mProgress.addContentView(new ProgressBar(PetInfo3View.this),
								new LayoutParams(LayoutParams.WRAP_CONTENT,
												LayoutParams.WRAP_CONTENT));
		mProgress.show();
		////
		try {
			ArrayList<String> result=ConnectDB.getPetInfo(id, string_pet_name);
			PetInfoItem petInfoItem = new PetInfoItem();
			if(result.get(0).equals("OK")){
				petInfoItem.setPet_name(result.get(1));
				petInfoItem.setAge(result.get(2));
				petInfoItem.setType(result.get(3));
				petInfoItem.setDetail(result.get(4));
				petInfoItem.setSex(result.get(5));
				petInfoItem.setSpecific(result.get(6));
				//set to ui
				pet_name.setText(" " + petInfoItem.getPet_name());
				age.setText(" " + petInfoItem.getAge()+"��");
				kind.setText(" " + petInfoItem.getType());
				kind_detail.setText(" " + petInfoItem.getDetail());
				if(petInfoItem.getSex().equals("1"))
					sex.setText(" " + "��");
				else if(petInfoItem.getSex().equals("0"))
					sex.setText(" " + "��");
				else
					sex.setText("ERROR : DB connect error");
				specific.setText(" " + petInfoItem.getSpecific());
			}
			else if(result.get(0).equals("FIN"))
				Toast.makeText(getBaseContext(), "ERROR : DB result error", Toast.LENGTH_SHORT).show();
			else if(result.get(0).equals("NO"))
				Toast.makeText(getBaseContext(), "ERROR : DB data doesn't exist error",Toast.LENGTH_SHORT).show();
			else
				Toast.makeText(getBaseContext(), "ERROR : DB connect error",Toast.LENGTH_SHORT).show();
			
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		mProgress.dismiss();
		
		/* ���̵�޴� ��ư�� ��� ���� */
		Button btnLogOut = (Button) findViewById(R.id.btnLogOut);
		btnLogOut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingLogoutPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnGetPetInfo = (Button) findViewById(R.id.btnGetPetInfo);
		btnGetPetInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnRsv = (Button) findViewById(R.id.btnRsv);
		btnRsv.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					if(ConnectDB.getPetNumberAvailable()) {
						Intent intent = new Intent(getBaseContext(), Reservation.class);
						ConnectDB.deleteActListExceptMain();
						startActivity(intent);
					}
					else {
						Toast.makeText(getBaseContext(), "��ϵ� ���� �����ϴ�", Toast.LENGTH_SHORT).show(); 
					}
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnMyRsvList = (Button) findViewById(R.id.btnMyRsvList);
		btnMyRsvList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnQuestion = (Button) findViewById(R.id.btnQuestion);
		btnQuestion.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), Board.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
				
			}
		});

		Button btnHptInfo = (Button) findViewById(R.id.btnHptInfo);
		btnHptInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), ClinicInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		/******** ȸ��Ż��!!!!! ********/
		Button btnWithdraw = (Button) findViewById(R.id.btnWithdraw);
		btnWithdraw.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// pop up
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingWithdrawPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		/******** ȸ��Ż��!!!!! ********/

		sliding_menu.getMainView().findViewById(R.id.btnMyMenu)
				.setOnClickListener(sliding_menu.getClickListener());
		/* ���̵�޴� ��ư�� ��� ���� */


	}
}
