package com.example.lovepetclinic;


import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.ActionBar.LayoutParams;
import android.app.ActionBar.Tab;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


public class ReservationView extends ActionBarActivity {

	public String id;
     
    @SuppressLint("NewApi") @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ConnectDB.addActList(this);
        
        id = ConnectDB.getId();
        
        /* �׼ǹ� ��Ÿ�� ���� - �׼ǹ� ���� tab�� �״�� ���� */
        // �׼ǹٸ� ���� �����Ͽ� ��带 �����մϴ�.
        ActionBar abar = getActionBar();
        abar.setNavigationMode( ActionBar.NAVIGATION_MODE_TABS );
        abar.setDisplayShowTitleEnabled(false);
        abar.setDisplayShowHomeEnabled(false);
        abar.setStackedBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.color_white)));
        abar.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.color_white)));
        abar.setSplitBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.color_white)));
        /* �׼ǹ� ��Ÿ�� ���� */
        
        Tab r1_clinic = abar.newTab();
        r1_clinic.setCustomView(R.layout.tab_background_hpt);
        //r1_clinic.setText("����");
        r1_clinic.setTabListener(new ProductTabListener(this, ReservationView1Clinic.class.getName()));
        abar.addTab(r1_clinic);
 
        Tab r2_hotel = abar.newTab();
        r2_hotel.setCustomView(R.layout.tab_background_htl);
        //r2_hotel.setText("ȣ��");
        r2_hotel.setTabListener(new ProductTabListener(this, ReservationView2Hotel.class.getName()));
        abar.addTab(r2_hotel);
 
        Tab r3_beauty = abar.newTab();
        r3_beauty.setCustomView(R.layout.tab_background_bty);
        //r3_beauty.setText("�̿�");
        r3_beauty.setTabListener(new ProductTabListener(this, ReservationView3Beauty.class.getName()));
        abar.addTab(r3_beauty);
        
        
    }
 
    /**
     * ���� �������� �� ó���� ������ ����
     */
    private class ProductTabListener implements ActionBar.TabListener {
        private Fragment mFragment;
        private Activity mActivity;
        private String mFragName;
 
        public ProductTabListener(Activity activity, String fragName) {
        	if(ConnectDB.isNetworkAvailable()) {
	            mActivity = activity;
	            mFragName = fragName;
        	} /* connection Ȯ�� */
			else
				 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
						 Toast.LENGTH_SHORT).show();
        }
 
        @Override
        public void onTabReselected(Tab tab, FragmentTransaction arg1) {
             
        }
 
        /**
         * ���� ���õǾ��� ��
         */
        @Override
        public void onTabSelected(Tab tab, FragmentTransaction ft) {
        	if(ConnectDB.isNetworkAvailable()) {
	            mFragment = Fragment.instantiate(mActivity, mFragName);
	            ft.add(android.R.id.content, mFragment);
        	} /* connection Ȯ�� */
			else
				 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
						 Toast.LENGTH_SHORT).show();
        }
 
        /**
         * �� ������ �����Ǿ��� ��
         */
        @Override
        public void onTabUnselected(Tab tab, FragmentTransaction ft) {
        	if(ConnectDB.isNetworkAvailable()) {
	            ft.remove(mFragment);
	            mFragment = null;
        	}/* connection Ȯ�� */
			else
				 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
						 Toast.LENGTH_SHORT).show();
        }
 
    }
  
}

