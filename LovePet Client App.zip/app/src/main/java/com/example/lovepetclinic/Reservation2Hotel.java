package com.example.lovepetclinic;


import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.ConnectDB;
import com.example.lovepetclinic.R;

import android.app.Dialog;
import android.app.Fragment;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Reservation2Hotel extends Fragment{

    private String[] pets;//={"������","�ʶ���","����"};
    String petName;
    Bundle bundle;
    int in_day;
	int in_year;
	int in_month;
	int out_day;
	int out_year;
	int out_month;
	String id = ConnectDB.getId();
	String user_name =ConnectDB.getUserName();
	private DatePicker in_date = null;
	private DatePicker out_date = null;
	
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
        View view=inflater.inflate( R.layout.reservation2_hotel, container, false );
        ConnectDB.setActivity(getActivity()); // ��Ʈ��ũ ����Ȯ�� �ϱ� ����
        //progress
		Dialog mProgress=new Dialog(getActivity(),R.style.MyDialog);
		mProgress.setCancelable(true);
		mProgress.addContentView(new ProgressBar(getActivity()),
								new LayoutParams(LayoutParams.WRAP_CONTENT,
												LayoutParams.WRAP_CONTENT));
		mProgress.show();
		////
        try {
			ArrayList<String> tempList = ConnectDB.getPetNames(id);
			tempList.remove(0);
			pets=tempList.toArray(new String[tempList.size()]);
			Log.d("�̿�test", Integer.toString(tempList.size()));
		} catch (ClientProtocolException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
        mProgress.dismiss();
        //spinner
        ArrayAdapter<String> petsList = new ArrayAdapter(getActivity(),
        		R.layout.spinner_item,pets);
        petsList.setDropDownViewResource(R.layout.spinner_dropdown);
		Spinner petsSpinner=(Spinner)view.findViewById(R.id.pet_spinner);
		petsSpinner.setAdapter(petsList);
		petsSpinner.setOnItemSelectedListener(new OnItemSelectedListener(){
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				TextView tv=(TextView)view;
				petName=String.valueOf(tv.getText());
				//Toast.makeText(getBaseContext(), String.valueOf(tv.getText()),Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				
			}
		});
    
		
		//datepicker1
		in_date=(DatePicker)view.findViewById(R.id.datePicker1);
		
		//datepicker2
		out_date=(DatePicker)view.findViewById(R.id.datePicker2);
		
		prepareDialog(in_date);
		
		prepareDialog(out_date);
		
		
		
		Button okBtn=(Button)view.findViewById(R.id.okBtn);
		okBtn.setOnClickListener(new OnClickListener(){
			
			@Override
			public void onClick(View v) {
				
				in_year=in_date.getYear();
				in_month=in_date.getMonth()+1;
				in_day=in_date.getDayOfMonth();
				
				out_year=out_date.getYear();
				out_month=out_date.getMonth()+1;
				out_day=out_date.getDayOfMonth();
				
				//progress
				Dialog mProgress=new Dialog(getActivity(),R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(getActivity()),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////
				
				
				Calendar cal = Calendar.getInstance();
				short year = (short) cal.get(Calendar.YEAR);
				byte month = (byte) cal.get(Calendar.MONTH);
				byte day = (byte) cal.get(Calendar.DATE);
				if(ConnectDB.isNetworkAvailable()) {
					if(pets.length>0){
						if(year*10000+(month+1)*100+day<=in_year*10000+in_month*100+in_day) {
//						if(in_year>=year&&out_year>=year&&in_month>=(month+1)&&out_month>=(month+1)&&in_day>=day&&out_day>=day){
							if(in_year*10000+in_month*100+in_day<out_year*10000+out_month*100+out_day) {
							//							if((in_year<=out_year)&&(in_month<=out_month)&&(in_day<out_day)){
								/* ��Ƽ��Ƽ ��ȯ */
								if(ConnectDB.isNetworkAvailable()) {
									bundle = new Bundle();
//									ArrayList<String> result=ConnectDB.reserveHospital(year, month, day, time, 
//											petName, id, user_name, detail.getText().toString());
									bundle.putString("in_year", String.valueOf(in_year));
									bundle.putString("in_month", String.valueOf(in_month));
									bundle.putString("in_day", String.valueOf(in_day));
									bundle.putString("out_year", String.valueOf(out_year));
									bundle.putString("out_month", String.valueOf(out_month));
									bundle.putString("out_day", String.valueOf(out_day));
									bundle.putString("id", id);
									bundle.putString("pet_name", petName);
									bundle.putString("user_name", user_name);
									Intent intent = new Intent(getActivity(), 
											ReservationConfirmHtl.class);//LoginActivity.class);
									intent.putExtras(bundle);
									startActivity(intent);
								}/* connection Ȯ�� */
								else
									 Toast.makeText(getActivity(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
											 		Toast.LENGTH_SHORT).show();
							}else
								Toast.makeText(getActivity(), "1�� 2�� �̻� ���ุ �����մϴ�", Toast.LENGTH_SHORT).show();
						}else
							Toast.makeText(getActivity(), "���� ��¥�� ������ �Ұ����մϴ�.", Toast.LENGTH_SHORT).show();
				
					}else
						Toast.makeText(getActivity(), "������ �߰����ּ���.", Toast.LENGTH_SHORT).show();
					mProgress.dismiss();
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getActivity(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
			
		});
		
		return view;
    }
    
    private void prepareDialog(DatePicker date) {
        try {
            Field datePickerFields[] = date.getClass().getDeclaredFields();            
            for (Field field : datePickerFields) {
                if ("mSpinners".equals(field.getName())) {
                    field.setAccessible(true);
                    Object spinnersObj = new Object();
                    spinnersObj = field.get(date);
                    LinearLayout mSpinners = (LinearLayout) spinnersObj;
                    NumberPicker monthPicker = (NumberPicker) mSpinners.getChildAt(0);
                    NumberPicker dayPicker = (NumberPicker) mSpinners.getChildAt(1);
                    NumberPicker yearPicker = (NumberPicker) mSpinners.getChildAt(2);
                    setDividerColor(monthPicker);
                    setDividerColor(dayPicker);
                    setDividerColor(yearPicker);
                    break;
                }
            }
        } catch (Exception ex) {
            
        }
    }
    
    private void setDividerColor(NumberPicker picker) {
        Field[] numberPickerFields = NumberPicker.class.getDeclaredFields();
        for (Field field : numberPickerFields) {
            if (field.getName().equals("mSelectionDivider")) {
                field.setAccessible(true);
                try {
                    field.set(picker, getResources().getDrawable(R.color.color_pink_light));
                } catch (IllegalArgumentException e) {
//                    Log.v(TAG, "Illegal Argument Exception");
                    e.printStackTrace();
                } catch (Resources.NotFoundException e) {
//                    Log.v(TAG, "Resources NotFound");
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
//                    Log.v(TAG, "Illegal Access Exception");
                    e.printStackTrace();
                }
                break;
            }
        }
    }
     
}