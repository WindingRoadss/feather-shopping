package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class PetInfo extends AniListenerActivity{

	private ListView petList;
	private ArrayList<String> arrayList;
	private ArrayAdapter<String> adapter;
	private String id = ConnectDB.getId();
	private ArrayList<String> arrayListPetNames;
	private final static int REFRESH_RESULT = 1;
	
	public void onBackPressed() { 
		if(sliding_menu.onBackFunction() == 0) { // ���̵� �޴��� ��Ÿ�� ���� ���� ���¸� finish
			finish();
		}
	}
	
	/* sliding menu�� �̸��� �̸��� ���� */
	private String str_user_name = ConnectDB.getUserName();
	private String str_email = ConnectDB.getUserEmail();
	/* sliding menu�� �̸��� �̸��� ���� */

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pet_info);
		
		ConnectDB.setActivity(this); // ��Ʈ��ũ ����Ȯ�� �ϱ� ����

		ConnectDB.addActList(this); // Activity �߰�
		
		/* Sliding Menu options */
		sliding_menu = new SlidingMenu(this);
		sliding_menu.setMenu(findViewById(R.id.menu));
		sliding_menu.setMainView(findViewById(R.id.mainView));
		/* Sliding Menu options */
		
		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		//�ٲ�� �� img_question_bar
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_petinfo_bar); 
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		
		/* userName and userEmail Setting  */
		TextView userName = (TextView)findViewById(R.id.userName);
		Log.d("setTextTest", "str_user_name" + str_user_name);
		userName.setText(str_user_name);
		TextView userEmail = (TextView)findViewById(R.id.userEmail);
		userEmail.setText(str_email);
		TextView petInfoText = (TextView)findViewById(R.id.petInfoText);
		petInfoText.setText(str_user_name + "���� ��������");
		/* userName and userEmail Setting  */
		//progress
		Dialog mProgress=new Dialog(PetInfo.this,R.style.MyDialog);
		mProgress.setCancelable(true);
		mProgress.addContentView(new ProgressBar(PetInfo.this),
								new LayoutParams(LayoutParams.WRAP_CONTENT,
												LayoutParams.WRAP_CONTENT));
		mProgress.show();
		////
		try {
			ArrayList<String> tempList = ConnectDB.getPetNames(id);
			tempList.remove(0);
			arrayListPetNames = tempList;
			// s=tempList.toArray(new String[tempList.size()]);
			Log.d("�������� ����", Integer.toString(tempList.size()));
		} catch (ClientProtocolException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		mProgress.dismiss();
		Button insertPetInfoBtn = (Button) findViewById(R.id.insertPetBtn);
		insertPetInfoBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(),
						PetInfo2Insert.class);
				startActivityForResult(intent, REFRESH_RESULT); // refresh�Ϸ���
			}

		});
		
		/* ���̵�޴� ��ư�� ��� ���� */
		Button btnLogOut = (Button) findViewById(R.id.btnLogOut);
		btnLogOut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingLogoutPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnGetPetInfo = (Button) findViewById(R.id.btnGetPetInfo);
		btnGetPetInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnRsv = (Button) findViewById(R.id.btnRsv);
		btnRsv.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					if(ConnectDB.getPetNumberAvailable()) {
						Intent intent = new Intent(getBaseContext(), Reservation.class);
						ConnectDB.deleteActListExceptMain();
						startActivity(intent);
					}
					else {
						Toast.makeText(getBaseContext(), "��ϵ� ���� �����ϴ�", Toast.LENGTH_SHORT).show(); 
					}
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnMyRsvList = (Button) findViewById(R.id.btnMyRsvList);
		btnMyRsvList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnQuestion = (Button) findViewById(R.id.btnQuestion);
		btnQuestion.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), Board.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
				
			}
		});

		Button btnHptInfo = (Button) findViewById(R.id.btnHptInfo);
		btnHptInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), ClinicInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		/******** ȸ��Ż��!!!!! ********/
		Button btnWithdraw = (Button) findViewById(R.id.btnWithdraw);
		btnWithdraw.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// pop up
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingWithdrawPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		/******** ȸ��Ż��!!!!! ********/

		sliding_menu.getMainView().findViewById(R.id.btnMyMenu)
				.setOnClickListener(sliding_menu.getClickListener());
		/* ���̵�޴� ��ư�� ��� ���� */

		// add
		arrayList = new ArrayList<String>();
		addPetNameToPetList();
		adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, arrayList);

		petList = (ListView) findViewById(R.id.petListView);
		petList.setAdapter(adapter);
		petList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

		petList.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long lid) {
				String pet_name = (String) adapter.getItem(position);
				Bundle bundle = new Bundle();
				bundle.putString("pet_name", pet_name);

				Intent intent = new Intent(getBaseContext(), PetInfo1Menu.class);
				intent.putExtras(bundle);
				startActivityForResult(intent, REFRESH_RESULT);
			}

		});

	}

	void addPetNameToPetList() {
		// dbdb getPetName
		for (int i = 0; i < arrayListPetNames.size(); i++) { // pets.length-1���� -1�� status ok�� no�� ���ִ� ��
			arrayList.add(arrayListPetNames.get(i));
		}
	}

	// refresh�� ���� resultó�� �κ�
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		switch (requestCode) {
		case REFRESH_RESULT:

			if (resultCode == RESULT_OK) {
				Intent refresh = new Intent(this, PetInfo.class);
				startActivity(refresh);
				this.finish();
			}
			break;
		}
	}
}
