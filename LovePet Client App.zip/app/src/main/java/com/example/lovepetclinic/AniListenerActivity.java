package com.example.lovepetclinic;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.Toast;


public class AniListenerActivity extends ActionBarActivity implements AnimationListener {

	SlidingMenu sliding_menu;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	
	}
	@Override
    public void onAnimationEnd(Animation animation) {
        System.out.println("onAnimationEnd");
        //ViewUtils.printView("menu", sliding_menu.getMenu());
        //ViewUtils.printView("mainView", sliding_menu.getMainView());
        sliding_menu.setMenuOut(!sliding_menu.getMenuOut());
        if (!sliding_menu.getMenuOut()) {
            sliding_menu.getMenu().setVisibility(View.INVISIBLE);
        }
        sliding_menu.layoutApp(sliding_menu.getMenuOut());
        //layoutApp(menuOut);
    }

    @Override
    public void onAnimationRepeat(Animation animation) {
        System.out.println("onAnimationRepeat");
    }

    @Override
    public void onAnimationStart(Animation animation) {
        System.out.println("onAnimationStart");
    }
    
}