package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Board extends AniListenerActivity {

	public void onBackPressed() {
		if (sliding_menu.onBackFunction() == 0) { // ���̵� �޴��� ��Ÿ�� ���� ���� ���¸�
													// finish
			finish();
		}
	}

	private String str_user_name = ConnectDB.getUserName();
	private String str_email = ConnectDB.getUserEmail();
	private String id = ConnectDB.getId();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.board); // board.xml �� �ҷ���
		
		ConnectDB.setActivity(this);
		
		ConnectDB.addActList(this); // Activity �߰�

		/* Sliding Menu options */
		sliding_menu = new SlidingMenu(this);

		sliding_menu.setMenu(findViewById(R.id.menu));
		sliding_menu.setMainView(findViewById(R.id.mainView));
		/* Sliding Menu options */

		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1];
		actionBarBackGrnd[0] = this.getResources().getDrawable(
				R.drawable.img_question_bar);

		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */

		/* userName and userEmail Setting */
		TextView userName = (TextView) findViewById(R.id.userName);
		Log.d("setTextTest", "str_user_name" + str_user_name);
		userName.setText(str_user_name);
		TextView userEmail = (TextView) findViewById(R.id.userEmail);
		userEmail.setText(str_email);
		/* userName and userEmail Setting */

		// faqBtn
		Button qnaBtn = (Button) findViewById(R.id.qnaBtn);
		qnaBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(getBaseContext(), "������ ������ ����������� ���̹� ���α׷� ����˴ϴ�", Toast.LENGTH_SHORT)
						.show(); // toast activity

				// ���� �� ������ ȭ�� �ϳ��� �ٽ� �ҷ����� ��
				Intent intent = new Intent(
						Intent.ACTION_VIEW,
						Uri.parse("http://m.blog.naver.com/PostList.nhn?blogId=sarang795&categoryNo=5&logCode=2"));
				startActivity(intent);
			}
		});
		// faqBtn
		Button faqBtn = (Button) findViewById(R.id.faqBtn);
		faqBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(getBaseContext(), "���� ��Ͻô� ģ���� �輱���� ī��� ����˴ϴ�.", Toast.LENGTH_SHORT)
						.show(); // toast activity

				// ���� �� ������ ȭ�� �ϳ��� �ٽ� �ҷ����� ��
				Intent intent = new Intent(
						Intent.ACTION_VIEW,
						Uri.parse("http://cafe.naver.com/onlinevet/39"));
				startActivity(intent);
			}
		});

		// questionBtn
		Button questionBtn = (Button) findViewById(R.id.questionBtn);
		questionBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Toast.makeText(getBaseContext(), "questionBtn",
				// Toast.LENGTH_SHORT).show(); //toast activity
				// Intent intent= new
				// Intent(getBaseContext(),Board2Question.class);
				// startActivity(intent);
				Intent it = new Intent(Intent.ACTION_SEND);
				it.setType("plain/text");

				// receiver add
				String[] tos = { "sarang7523@gmail.com" }; // add the email
				it.putExtra(Intent.EXTRA_EMAIL, tos);
				it.putExtra(Intent.EXTRA_SUBJECT, "���� ����");
				it.putExtra(Intent.EXTRA_TEXT, "");
				startActivity(it);

			}
		});

		Button callBtn = (Button) findViewById(R.id.callBtn);
		callBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
					Intent intentCall = new Intent();
					intentCall.setAction(Intent.ACTION_DIAL);
					Uri data = Uri.parse("tel:031-795-7524");
					intentCall.setData(data);
					startActivity(intentCall);
				

			}
		});

		/* ���̵�޴� ��ư�� ��� ���� */
		Button btnLogOut = (Button) findViewById(R.id.btnLogOut);
		btnLogOut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingLogoutPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnGetPetInfo = (Button) findViewById(R.id.btnGetPetInfo);
		btnGetPetInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnRsv = (Button) findViewById(R.id.btnRsv);
		btnRsv.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					if(ConnectDB.getPetNumberAvailable()) {
						Intent intent = new Intent(getBaseContext(), Reservation.class);
						ConnectDB.deleteActListExceptMain();
						startActivity(intent);
					}
					else {
						Toast.makeText(getBaseContext(), "��ϵ� ���� �����ϴ�", Toast.LENGTH_SHORT).show(); 
					}
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnMyRsvList = (Button) findViewById(R.id.btnMyRsvList);
		btnMyRsvList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnQuestion = (Button) findViewById(R.id.btnQuestion);
		btnQuestion.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), Board.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
				
			}
		});

		Button btnHptInfo = (Button) findViewById(R.id.btnHptInfo);
		btnHptInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), ClinicInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		/******** ȸ��Ż��!!!!! ********/
		Button btnWithdraw = (Button) findViewById(R.id.btnWithdraw);
		btnWithdraw.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// pop up
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingWithdrawPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		/******** ȸ��Ż��!!!!! ********/

		sliding_menu.getMainView().findViewById(R.id.btnMyMenu)
				.setOnClickListener(sliding_menu.getClickListener());
		/* ���̵�޴� ��ư�� ��� ���� */
	}
}
