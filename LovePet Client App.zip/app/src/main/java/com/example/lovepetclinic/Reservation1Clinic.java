package com.example.lovepetclinic;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.R.integer;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.CalendarView.OnDateChangeListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Reservation1Clinic extends Fragment{
     
	private ListView listView;
	private ImageView sticker;
    private ArrayList<String> data = new ArrayList<String>();
    private ArrayList<String> rsvTime = new ArrayList<String>(); //���� �ð� ����Ʈ (9��~16��)
    private ArrayList<Integer> ingIndexList = new ArrayList<Integer>(); // ���� ���� ����Ʈ
    private ArrayList<Integer> completeIndexList = new ArrayList<Integer>(); // ���� �Ϸ� �ε��� ����Ʈ
    private ArrayList<String> result_possibility;
    private ArrayAdapter arrayAdapter;
    private View listViewHeader;
    private TextView header;
    private TextView reserveText;
    private Intent intent;
    private Bundle bundle;  
    private Button mButtonNext, mButtonPrevious;
    String user_id = ConnectDB.getId();
    
    
 
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
    	
    	
    	final View view = inflater.inflate( R.layout.reservation1_clinic, container, false );
    	
    	ConnectDB.setActivity(getActivity()); // ��Ʈ��ũ ����Ȯ�� �ϱ� ����
    	
    	bundle = new Bundle();
    	
    	reserveText=(TextView)view.findViewById(R.id.reservationText);
    	
    	completeIndexList.add(-1); // ���� �ð� 0��° Ŭ�� ����
    	
    	//listView
    	listView = (ListView) view.findViewById(R.id.dateListView);
    	sticker = (ImageView) view.findViewById(R.id.img_sticker);
    	 
    	arrayAdapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1 ,data);
         
    	listView.setVisibility(View.GONE); //ó���� �Ⱥ��̰�
    	sticker.setVisibility(View.GONE); //ó���� �Ⱥ��̰�
    	//listview ������ ����
    	listViewHeader=getActivity().getLayoutInflater().inflate(R.layout.reservation4_listview_header,null,false);
    	header=(TextView)listViewHeader.findViewById(R.id.reservation_listview_header);
    	listView.addHeaderView(listViewHeader);
    	listView.setHeaderDividersEnabled(true);
    	 
    	 
    	
         //calendarView
    	final CalendarView cal=(CalendarView)view.findViewById(R.id.clinicCal);
	
    	//sets whether to show the week number.
		cal.setShowWeekNumber(false);

		// sets the first day of week according to Calendar.
		// here we set Monday as the first day of the Calendar
		cal.setFirstDayOfWeek(1); //�Ͽ��Ϻ��� ����
		
		//The background color for the selected week.
		cal.setSelectedWeekBackgroundColor(getResources().getColor(R.color.color_pink_light));
		
		//sets the color for the dates of an unfocused month. 
		cal.setUnfocusedMonthDateColor(getResources().getColor(R.color.transparent));
	
		//sets the color for the separator line between weeks.
		cal.setWeekSeparatorLineColor(getResources().getColor(R.color.transparent));
		
		//sets the color for the vertical bar shown at the beginning and at the end of the selected date.
		cal.setSelectedDateVerticalBar(R.color.color_white);
		
    	
    	cal.setOnDateChangeListener(new OnDateChangeListener(){

			@Override
			public void onSelectedDayChange(CalendarView view, int year,
					int month, int dayOfMonth) {
				
				Calendar cal = Calendar.getInstance();
				int today_year = (short) cal.get(Calendar.YEAR);
				int today_month = (byte) cal.get(Calendar.MONTH);
				int today_day = (byte) cal.get(Calendar.DATE);
				int realMonth=month+1; //month�� 1���� ����
				if(today_year*10000+(today_month+1)*100+today_day<=year*10000+realMonth*100+dayOfMonth){	
					//reserveText.setVisibility(View.GONE);
					//listview ����
					completeIndexList.removeAll(completeIndexList); // �ٽ� ���� �Ϸ� �ð��� �ش� ��¥ ������ ���� �ִ� ������ �ٲٱ� ����
					completeIndexList.add(-1); // ���� �ð� 0��° Ŭ�� ��
					data.removeAll(data);//initialize
					bundle.clear(); //initialize
					//Toast.makeText(getActivity(), String.valueOf(year+" "+realMonth+" "+dayOfMonth),Toast.LENGTH_SHORT).show();
					addData(year,realMonth,dayOfMonth);
					listView.setVisibility(View.VISIBLE);
					sticker.setVisibility(View.VISIBLE);
					//header��¥ �ٲٱ�
					header.setText(year+"�� "+realMonth+"�� "+dayOfMonth+"�� ");
					//header.setText(year+" "+realMonth+" "+dayOfMonth+" >> �����Ͻ� �ð��� �����ϼ���");
					listView.setAdapter(arrayAdapter);
					
					
					bundle.putString("year", String.valueOf(year));
					bundle.putString("month", String.valueOf(realMonth));
					bundle.putString("day", String.valueOf(dayOfMonth));
				}else
					Toast.makeText(getActivity(), "���ų�¥�� ������ �Ұ����մϴ�.",Toast.LENGTH_SHORT).show();
				
			}
			
			

    	});
    	
    	
    	/* next month and previous month */
    	mButtonNext = (Button)view.findViewById(R.id.btnNextMonth);
    	mButtonNext.setOnClickListener(new OnClickListener() {
 	        @Override
 	        public void onClick(View v) {
 	            Calendar calendar = new GregorianCalendar();
 	            calendar.setTimeInMillis(cal.getDate() );
 	            calendar.add(Calendar.MONTH, 1);
 	            cal.setDate(calendar.getTimeInMillis(), true, true);
 	        }
 	    });

 	    mButtonPrevious = (Button)view.findViewById(R.id.btnPreviousMonth);
 	    mButtonPrevious.setOnClickListener(new OnClickListener() {
 	        @Override
 	        public void onClick(View v) {
 	            Calendar calendar = new GregorianCalendar();
 	            calendar.setTimeInMillis(cal.getDate() );
 	            calendar.add(Calendar.MONTH, -1);                
 	            cal.setDate(calendar.getTimeInMillis(), true, true);
 	        }
 	    });
 	    /* next month and previous month */
    	
    	
    	
    	  
    	listView.setOnItemClickListener(new OnItemClickListener(){

			@SuppressLint("UseValueOf") @Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				//progress
				if(ConnectDB.isNetworkAvailable()) {
					Dialog mProgress=new Dialog(getActivity(),R.style.MyDialog);
					mProgress.setCancelable(true);
					mProgress.addContentView(new ProgressBar(getActivity()),
											new LayoutParams(LayoutParams.WRAP_CONTENT,
															LayoutParams.WRAP_CONTENT));
					mProgress.show();
					////
					boolean rightTime=false;
					Calendar cal = Calendar.getInstance();
					int today_time = (short) cal.get(Calendar.HOUR_OF_DAY);
					int today_year = (short) cal.get(Calendar.YEAR);
					int today_month = (byte) cal.get(Calendar.MONTH);
					int today_day = (byte) cal.get(Calendar.DATE);
					String time=String.valueOf(position+9);
					if(today_year==Integer.parseInt(bundle.getString("year")) &&
						(today_month+1)==Integer.parseInt(bundle.getString("month")) &&
						today_day==Integer.parseInt(bundle.getString("day"))){
						if(Integer.parseInt(time)>today_time)
							rightTime=true;
						else
							rightTime=false;
					}
					else rightTime=true;
					if(rightTime){
						boolean clickAvailabel = true;
						//Log.d("listView", "listView : ingIndexList compare Start" + " " + String.valueOf(ingIndexList.get(0)));
						Log.d("listView", "item position : item position" + " " + String.valueOf(position));
						
						if(position - 1 == -1) { //�� �� ����Ʈ ������ Ŭ�� ��
							clickAvailabel = false;
						}
						else {
							for(int i = 0; i < completeIndexList.size(); i++) {
								//Integer compare_pos = new Integer(position);
								if((position) == completeIndexList.get(i) + 1) {
									clickAvailabel = false;
									Log.d("listView", "listView index: " + String.valueOf(completeIndexList.get(i)));
								}
			//					else
			//						ingIndexList.remove(0);
							}
						}
						if(clickAvailabel) {
						try {
			//					Toast.makeText(getActivity(),bundle.getString("year")+" "+bundle.getString("month")
			//							+" "+bundle.getString("day")+" "+time
			//							, Toast.LENGTH_LONG).show();
								result_possibility=ConnectDB.hpReservePossiblity(user_id, bundle.getString("year"),
								bundle.getString("month"),bundle.getString("day"),time);
	//							Toast.makeText(getActivity(), result_possibility.get(0), Toast.LENGTH_LONG).show();
								
							} catch (ClientProtocolException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							}
							bundle.putString("time",time);
							if(result_possibility.get(0) == "FIN") {
								intent=new Intent(getActivity(),Reservation1ClinicNext.class);
								intent.putExtras(bundle);
								startActivity(intent);
							}
							else;
	//							Toast.makeText(getActivity(), result_possibility.get(0), Toast.LENGTH_LONG).show();
						}
					}else{
						Toast.makeText(getActivity(), "���డ���� �ð��� �ƴմϴ�", Toast.LENGTH_SHORT).show();
					}
					mProgress.dismiss();
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getActivity(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
			
    		
    	});
          
    	return view;
        
    }
    
    private void addData(int y,int m, int d){
    	final int OPENTIME=10;
    	String year=String.valueOf(y);
    	String month=String.valueOf(m);
    	String day=String.valueOf(d);
    	ArrayList<Integer> locList = new ArrayList<Integer>(); //���� �� �ð� ����
    	int k = 0; //���� �� ����Ʈ �ð� index
    	//progress
		Dialog mProgress=new Dialog(getActivity(),R.style.MyDialog);
		mProgress.setCancelable(true);
		mProgress.addContentView(new ProgressBar(getActivity()),
								new LayoutParams(LayoutParams.WRAP_CONTENT,
												LayoutParams.WRAP_CONTENT));
		mProgress.show();
		////
    	try {
			ArrayList<String> result=ConnectDB.getIsReservedHpt(year,month,day);
			ArrayList<String> result_ing=ConnectDB.getIsReservedIngHpt(user_id, year, month, day);
			
			for(int time=OPENTIME;time<22;time++) {
				data.add(String.valueOf(time+" : 00"));
				rsvTime.add(String.valueOf(time));
			}
			Log.d("Reservation1Clinic resultIngList Size : ", String.valueOf(result_ing.size()));
			if(result_ing.get(0).equals("OK")){
				for(int i=1;i<result_ing.size();i+=2){
					locList.add(Integer.valueOf(result_ing.get(i))-OPENTIME);
					int loc_n = Integer.valueOf(result_ing.get(i))-OPENTIME;
					//Toast.makeText(getActivity(), String.valueOf(loc), Toast.LENGTH_SHORT).show();
					data.set(loc_n, data.get(loc_n)+" - ������");
					ingIndexList.add(loc_n); // Ŭ�� ���X
				}
				for(int i=2;i<result_ing.size(); i+=2){
					String rsv_id = result_ing.get(i);
					Log.d("Reservation1Clinic resultIngList id : ", rsv_id);
					int loc_n = Integer.valueOf(result_ing.get(i-1))-OPENTIME;
					if(rsv_id.equals(user_id)) {
						data.set(locList.get(k), rsvTime.get(locList.get(k))+" : 00 - "+ ConnectDB.getUserName() +"���� ���� ���̴� �ð��Դϴ�");
					}
					else {
						Log.d("Reservation1Clinic resultIngList id : ", rsv_id + " " + user_id);
						completeIndexList.add(loc_n);
						data.set(locList.get(k), rsvTime.get(locList.get(k))+" : 00 - " + "�ٸ� ����ڰ� ���� ���� �ð��Դϴ�");
					}
					k++; // locList �ε���++
				}
			}
			
			if(result.get(0).equals("OK")){
				for(int i=1;i<result.size(); i++){
					int loc_n=Integer.valueOf(result.get(i))-OPENTIME;
//					Toast.makeText(getActivity(), String.valueOf(loc_n), Toast.LENGTH_SHORT).show();
					data.set(loc_n,data.get(loc_n)+" - ����Ϸ�");
					completeIndexList.add(loc_n);
				}
			}
			
			
		
		
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	mProgress.dismiss();
    	
    }
    
}