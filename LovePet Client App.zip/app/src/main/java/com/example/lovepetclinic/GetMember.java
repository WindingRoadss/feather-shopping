package com.example.lovepetclinic;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class GetMember extends Activity {
	EditText id;
	EditText pwd;
	EditText name;
	EditText phone;
	EditText email;
	RadioGroup rg;
	RadioButton visited;
	RadioButton not_visited;
	Button ok;
	Button cancel;
	String visited_result=null;
	String result;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_member);
		
		ConnectDB.setActivity(this); // ��Ʈ��ũ ����Ȯ�� �ϱ� ����
		
		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_join_bar);
		
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		
		id=(EditText)findViewById(R.id.idEditText);
		pwd=(EditText)findViewById(R.id.passwordEditText);
		name=(EditText)findViewById(R.id.nameEditText);
		phone=(EditText)findViewById(R.id.phoneEditText);
		email=(EditText)findViewById(R.id.emailEditText);
		rg=(RadioGroup)findViewById(R.id.visitedClinicRadioGroup);
		visited=(RadioButton)findViewById(R.id.visitedRadioBtn);
		visited.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				visited_result="1";
			}
		});
		not_visited=(RadioButton)findViewById(R.id.notVisitedRadioBtn);
		not_visited.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				visited_result="0";
			}
		});
		ok=(Button)findViewById(R.id.okBtn);
		cancel =(Button)findViewById(R.id.cancelBtn);
		
		ok.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				//progress
				Dialog mProgress=new Dialog(GetMember.this,R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(GetMember.this),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////	
				if(ConnectDB.isNetworkAvailable()) {
					if((visited_result!=null)&&(!id.getText().toString().equals(""))&&(!pwd.getText().toString().equals(""))
							&&(!name.getText().toString().equals(""))&&(!email.getText().toString().equals(""))&&(!phone.getText().toString().equals(""))){
						try {
							result=ConnectDB.addMember(name.getText().toString(),
												id.getText().toString(),
												pwd.getText().toString(),
												name.getText().toString(),
												visited_result,
												email.getText().toString(),
												phone.getText().toString());
	//						Toast.makeText(getBaseContext(), result, Toast.LENGTH_LONG).show();
						} catch (ClientProtocolException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						} //try catch
						if(result.equals("FIN")){
							Toast.makeText(getBaseContext(), "ȸ�������� �����Ͽ����ϴ�.", Toast.LENGTH_SHORT).show();
							finish();
						}
						else if(result.equals("NO"))
							Toast.makeText(getBaseContext(), "ȸ�������� �����Ͽ����ϴ�.", Toast.LENGTH_SHORT).show();
						else
							Toast.makeText(getBaseContext(), "ERROR : DB connection error", Toast.LENGTH_SHORT).show();
					}//if
					else
						Toast.makeText(getBaseContext(), "������ ������ �ٽ� Ȯ���� �ּ���", Toast.LENGTH_SHORT).show();
					mProgress.dismiss();
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		
		

		
		
	}
}
