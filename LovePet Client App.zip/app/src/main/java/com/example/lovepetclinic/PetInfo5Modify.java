package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PetInfo5Modify extends AniListenerActivity {

	String id=ConnectDB.getId();
	TextView pet_name;
	EditText age;
	Spinner kindSpinner;
	EditText kind_detail;
	RadioGroup rg;
	RadioButton man;
	RadioButton woman;
	EditText specific;
	Button ok;
	Button cancel;
	String sex=null;
	ArrayList<String> result=null;
	ArrayList<String> kind= new ArrayList<String>();
	
	public void onBackPressed() { 
		if(sliding_menu.onBackFunction() == 0) { // ���̵� �޴��� ��Ÿ�� ���� ���� ���¸� finish
			finish();
		}
	}
	
	/* sliding menu�� �̸��� �̸��� ���� */
	private String str_user_name = ConnectDB.getUserName();
	private String str_email = ConnectDB.getUserEmail();
	/* sliding menu�� �̸��� �̸��� ���� */
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pet_info5_modify);
		Bundle bundle=getIntent().getExtras();
		String string_pet_name=bundle.getString("pet_name");
		
		ConnectDB.addActList(this); // Activity �߰�
		
		/* Sliding Menu options */
		sliding_menu = new SlidingMenu(this);
		
		sliding_menu.setMenu(findViewById(R.id.menu));
		sliding_menu.setMainView(findViewById(R.id.mainView));
		/* Sliding Menu options */

		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_petinfo_modify_bar); 
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		
		/* userName and userEmail Setting  */
		TextView userName = (TextView)findViewById(R.id.userName);
		Log.d("setTextTest", "str_user_name" + str_user_name);
		userName.setText(str_user_name);
		TextView userEmail = (TextView)findViewById(R.id.userEmail);
		userEmail.setText(str_email);
		/* userName and userEmail Setting  */
		
		//ui 
//		setContentView(R.layout.pet_info5_modify);
		pet_name=(TextView)findViewById(R.id.petNameTextView);
		age=(EditText)findViewById(R.id.ageEditText);
		kindSpinner = (Spinner)findViewById(R.id.kindSpinner);
		kind_detail=(EditText)findViewById(R.id.kindEditText);
		rg=(RadioGroup)findViewById(R.id.sexRadioGroup);
		man=(RadioButton)findViewById(R.id.manRadioBtn);
		man.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				sex="1";
			}
		});
		woman=(RadioButton)findViewById(R.id.womanRadioBtn);
		woman.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				sex="0";
			}
		});
		specific=(EditText)findViewById(R.id.specificEditText);
		ok=(Button)findViewById(R.id.okBtn);
		cancel =(Button)findViewById(R.id.cancelBtn);
		//get kind from db
		getKind();
		//pet Spinner
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(),
											R.layout.spinner_item, kind);
		adapter.setDropDownViewResource(R.layout.spinner_dropdown);
		kindSpinner.setAdapter(adapter);
		
		//progress
		Dialog mProgress=new Dialog(PetInfo5Modify.this,R.style.MyDialog);
		mProgress.setCancelable(true);
		mProgress.addContentView(new ProgressBar(PetInfo5Modify.this),
								new LayoutParams(LayoutParams.WRAP_CONTENT,
												LayoutParams.WRAP_CONTENT));
		mProgress.show();
		////
		//get petInfo
		try {
			ArrayList<String> result=ConnectDB.getPetInfo(id, string_pet_name);
			PetInfoItem petInfoItem = new PetInfoItem();
			if(result.get(0).equals("OK")){
				petInfoItem.setPet_name(result.get(1));
				petInfoItem.setAge(result.get(2));
				petInfoItem.setType(result.get(3));
				petInfoItem.setDetail(result.get(4));
				petInfoItem.setSex(result.get(5));
				petInfoItem.setSpecific(result.get(6));
				//set to ui
				pet_name.setText(petInfoItem.getPet_name());
				age.setText(petInfoItem.getAge());
				int kind_index=kind.indexOf(petInfoItem.getType());
				kindSpinner.setSelection(kind_index);
				kind_detail.setText(petInfoItem.getDetail());
				if(petInfoItem.getSex().equals("1")){
					rg.check(R.id.manRadioBtn);
					sex="1";
				}
				else if(petInfoItem.getSex().equals("0")){
					rg.check(R.id.womanRadioBtn);
					sex="0";
				}
				specific.setText(petInfoItem.getSpecific());
			}
			else if(result.get(0).equals("FIN"))
				Toast.makeText(getBaseContext(), "ERROR : DB result error", Toast.LENGTH_SHORT).show();
			else if(result.get(0).equals("NO"))
				Toast.makeText(getBaseContext(), "ERROR : DB data doesn't exist error",Toast.LENGTH_SHORT).show();
			else
				Toast.makeText(getBaseContext(), "ERROR : DB connect error",Toast.LENGTH_SHORT).show();
			
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		mProgress.dismiss();
		
		/* ���̵�޴� ��ư�� ��� ���� */
		Button btnLogOut = (Button) findViewById(R.id.btnLogOut);
		btnLogOut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingLogoutPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnGetPetInfo = (Button) findViewById(R.id.btnGetPetInfo);
		btnGetPetInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnRsv = (Button) findViewById(R.id.btnRsv);
		btnRsv.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					if(ConnectDB.getPetNumberAvailable()) {
						Intent intent = new Intent(getBaseContext(), Reservation.class);
						ConnectDB.deleteActListExceptMain();
						startActivity(intent);
					}
					else {
						Toast.makeText(getBaseContext(), "��ϵ� ���� �����ϴ�", Toast.LENGTH_SHORT).show(); 
					}
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnMyRsvList = (Button) findViewById(R.id.btnMyRsvList);
		btnMyRsvList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnQuestion = (Button) findViewById(R.id.btnQuestion);
		btnQuestion.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), Board.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
				
			}
		});

		Button btnHptInfo = (Button) findViewById(R.id.btnHptInfo);
		btnHptInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), ClinicInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		/******** ȸ��Ż��!!!!! ********/
		Button btnWithdraw = (Button) findViewById(R.id.btnWithdraw);
		btnWithdraw.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// pop up
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingWithdrawPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		/******** ȸ��Ż��!!!!! ********/

		sliding_menu.getMainView().findViewById(R.id.btnMyMenu)
				.setOnClickListener(sliding_menu.getClickListener());
		/* ���̵�޴� ��ư�� ��� ���� */		
		
		
		ok.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				//progress
				Dialog mProgress=new Dialog(PetInfo5Modify.this,R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(PetInfo5Modify.this),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////
				if(sex!=null){
					try {
						result=ConnectDB.modifyPetInfo(id,
														pet_name.getText().toString(),
														age.getText().toString(),
														(String)kindSpinner.getSelectedItem(),
														kind_detail.getText().toString(),
														sex,
														specific.getText().toString());
						
//						Toast.makeText(getBaseContext(), result, Toast.LENGTH_LONG).show();
						if(result.get(0).equals("FIN")){
							Toast.makeText(getBaseContext(), "���������� �����Ͽ����ϴ�.", Toast.LENGTH_SHORT).show();
							//refresh�� ���� intent
							Intent intent = new Intent();
							intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							setResult(RESULT_OK,intent);
							finish();
						}
						else if(result.get(0).equals("NO"))
							Toast.makeText(getBaseContext(), "���������� �����Ͽ����ϴ�.", Toast.LENGTH_SHORT).show();
						else
							Toast.makeText(getBaseContext(), "ERROR : DB connection error", Toast.LENGTH_SHORT).show();	
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}//if
				else
					Toast.makeText(getBaseContext(), 
							"������ �������ּ���", Toast.LENGTH_SHORT)
							.show();
				mProgress.dismiss();
			}
		});
		
		
		cancel.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				finish();
			}
		});

	}
	
	void getKind(){
		kind.add("��");
		kind.add("������");
		kind.add("��Ÿ");
		
	}
	
	
}
