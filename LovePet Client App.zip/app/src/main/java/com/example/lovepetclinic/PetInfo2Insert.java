package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PetInfo2Insert extends AniListenerActivity {

	String id;
	EditText pet_name;
	EditText age;
	Spinner kindSpinner;
	EditText kind_detail;
	RadioGroup rg;
	RadioButton man;
	RadioButton woman;
	EditText specific;
	Button ok;
	Button cancel;
	String sex=null;
	String result=null;
	ArrayList<String> kind= new ArrayList<String>();
	
	public void onBackPressed() { 
		if(sliding_menu.onBackFunction() == 0) { // ���̵� �޴��� ��Ÿ�� ���� ���� ���¸� finish
			finish();
		}
	}
	
	/* sliding menu�� �̸��� �̸��� ���� */
	private String str_user_name = ConnectDB.getUserName();
	private String str_email = ConnectDB.getUserEmail();
	/* sliding menu�� �̸��� �̸��� ���� */
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pet_info2_insert);
		
		ConnectDB.setActivity(this); // ��Ʈ��ũ ����Ȯ�� �ϱ� ����
		
		id=ConnectDB.getId();
		ConnectDB.addActList(this); // Activity �߰�
		
		/* Sliding Menu options */
		sliding_menu = new SlidingMenu(this);
		
		sliding_menu.setMenu(findViewById(R.id.menu));
		sliding_menu.setMainView(findViewById(R.id.mainView));
		/* Sliding Menu options */

		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_petinfo_addpet_bar); 
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		
		/* userName and userEmail Setting  */
		TextView userName = (TextView)findViewById(R.id.userName);
		Log.d("setTextTest", "str_user_name" + str_user_name);
		userName.setText(str_user_name);
		TextView userEmail = (TextView)findViewById(R.id.userEmail);
		userEmail.setText(str_email);
		/* userName and userEmail Setting  */
		

		
		pet_name=(EditText)findViewById(R.id.petNameEditText);
		age=(EditText)findViewById(R.id.ageEditText);
		kindSpinner = (Spinner)findViewById(R.id.kindSpinner);
		kind_detail=(EditText)findViewById(R.id.kindEditText);
		rg=(RadioGroup)findViewById(R.id.sexRadioGroup);
		man=(RadioButton)findViewById(R.id.manRadioBtn);
		man.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				sex="1";
			}
		});
		woman=(RadioButton)findViewById(R.id.womanRadioBtn);
		woman.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				sex="0";
			}
		});
		specific=(EditText)findViewById(R.id.specificEditText);
		ok=(Button)findViewById(R.id.okBtn);
		cancel =(Button)findViewById(R.id.cancelBtn);
		//get kind from db
		getKind();
		//pet Spinner
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(),
											R.layout.spinner_item, kind);
		adapter.setDropDownViewResource(R.layout.spinner_dropdown);
		kindSpinner.setAdapter(adapter);
		
		
		
		/* ���̵�޴� ��ư�� ��� ���� */
		Button btnLogOut = (Button)findViewById(R.id.btnLogOut);
		btnLogOut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getBaseContext(), "btnLogOut",
						Toast.LENGTH_SHORT).show(); // toast activity
				ConnectDB.setId("default"); // �α׾ƿ��� ���̵� �� ����Ʈ��
				//ConnectDB.setEmail("abcdefg@naver.com"); // email�� ����Ʈ��
				ConnectDB.deleteAllActList();
				Intent intent = new Intent(getBaseContext(), LoginActivity.class);
				startActivity(intent);
				finish();
			}
		});
		
		Button btnGetPetInfo = (Button)findViewById(R.id.btnGetPetInfo);
		btnGetPetInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(ConnectDB.isNetworkAvailable()) {
					Toast.makeText(getBaseContext(), "btnGetPetInfo",
							Toast.LENGTH_SHORT).show(); // toast activity
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					startActivity(intent);
					ConnectDB.deleteActListExceptMain();
				}
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();			}
		});
		
		Button btnRsv = (Button)findViewById(R.id.btnRsv);
		btnRsv.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(ConnectDB.isNetworkAvailable()) {
					if(ConnectDB.getPetNumberAvailable()) {
						Intent intent = new Intent(getBaseContext(), Reservation.class);
						ConnectDB.deleteActListExceptMain();
						startActivity(intent);
					}
					else {
						Toast.makeText(getBaseContext(), "��ϵ� ���� �����ϴ�", Toast.LENGTH_SHORT).show(); 
					}
				}
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();			
			}
		});
		
		
		Button btnMyRsvList = (Button)findViewById(R.id.btnMyRsvList);
		btnMyRsvList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(ConnectDB.isNetworkAvailable()) {
					Toast.makeText(getBaseContext(), "btnMyRsvList",
							Toast.LENGTH_SHORT).show(); // toast activity
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					startActivity(intent);
					ConnectDB.deleteActListExceptMain();
				}
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();			
			}
		});
		
		Button btnQuestion= (Button)findViewById(R.id.btnQuestion);
		btnQuestion.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getBaseContext(), "btnQuestion",
						Toast.LENGTH_SHORT).show(); // toast activity
				Intent intent = new Intent(getBaseContext(), Board.class);
				startActivity(intent);
				ConnectDB.deleteActListExceptMain();
			}
		});
		
		Button btnHptInfo= (Button)findViewById(R.id.btnHptInfo);
		btnHptInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getBaseContext(), "btnHptInfo",
						Toast.LENGTH_SHORT).show(); // toast activity
				Intent intent = new Intent(getBaseContext(), ClinicInfo.class);
				startActivity(intent);
				ConnectDB.deleteActListExceptMain();
			}
		});
		/********ȸ��Ż��!!!!!********/
		Button btnWithdraw = (Button)findViewById(R.id.btnWithdraw);
		btnWithdraw.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
//				Toast.makeText(getBaseContext(), "btnWithdraw",
//						Toast.LENGTH_SHORT).show(); // toast activity
				//pop up
				if(ConnectDB.isNetworkAvailable()) {
					try {
						ArrayList<String> result=ConnectDB.withDraw(id);
						if(result.get(0).equals("FIN")) {
							Toast.makeText(getBaseContext(), "Ż��Ǿ����ϴ�", Toast.LENGTH_SHORT).show();
							ConnectDB.deleteAllActList();
							Intent intent = new Intent(getBaseContext(), LoginActivity.class);
							startActivity(intent);
							finish();
						}
						else if(result.get(0).equals("NO"))
							Toast.makeText(getBaseContext(), "Ż�� ó���� ���� �ʾҽ��ϴ�", Toast.LENGTH_SHORT).show();
						else
							Toast.makeText(getBaseContext(), "ERROR : DB result error", Toast.LENGTH_SHORT).show();
							
					} catch (ClientProtocolException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		/********ȸ��Ż��!!!!!********/
		sliding_menu.getMainView().findViewById(R.id.btnMyMenu).setOnClickListener(sliding_menu.getClickListener());		
		/* ���̵�޴� ��ư�� ��� ���� */

		
		
		
		ok.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				//progress
				Dialog mProgress=new Dialog(PetInfo2Insert.this,R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(PetInfo2Insert.this),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////
				if(ConnectDB.isNetworkAvailable()) {
					if(sex!=null&&(!pet_name.getText().toString().equals(""))&&(!age.getText().toString().equals(""))
							&&kind.size()!=0&&(!kind_detail.getText().toString().equals(""))){
						try {
							result=ConnectDB.addPet(id,
												pet_name.getText().toString(),
												age.getText().toString(),
												(String)kindSpinner.getSelectedItem(),
												kind_detail.getText().toString(),
												sex,
												specific.getText().toString());
							if(result.equals("FIN")){
								Toast.makeText(getBaseContext(), "�����߰��� �����Ͽ����ϴ�.", Toast.LENGTH_SHORT).show();
								//refresh�� ���� intent
								ConnectDB.setPetNumberAvailable(true);
								Intent intent = new Intent();
								intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								setResult(RESULT_OK,intent);
								finish();
							}
							else if(result.equals("NO"))
								Toast.makeText(getBaseContext(), "�����߰��� �����Ͽ����ϴ�.", Toast.LENGTH_SHORT).show();
							else
								Toast.makeText(getBaseContext(), "ERROR : DB connection error", Toast.LENGTH_SHORT).show();
							
						} catch (ClientProtocolException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}//if
					else
						Toast.makeText(getBaseContext(), 
								"������ ������ Ȯ���� �ּ���", Toast.LENGTH_SHORT)
								.show();
					mProgress.dismiss();
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		
		
		cancel.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				finish();
			}
		});

	}
	
	void getKind(){
		kind.add("��");
		kind.add("������");
		kind.add("��Ÿ");
		
	}
	
	
}
