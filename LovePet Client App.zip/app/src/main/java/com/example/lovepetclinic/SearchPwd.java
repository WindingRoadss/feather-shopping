package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class SearchPwd extends Activity {
	EditText id;
	EditText name;
	EditText email;
	Button ok;
	Button cancel;
	ArrayList<String> result;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search_pwd);
		
		//ConnectDB.addActList(this); // Activity �߰�
		
		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_search_pwd_bar);
		
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		
		id=(EditText)findViewById(R.id.idEditText);
		name=(EditText)findViewById(R.id.nameEditText);
		email=(EditText)findViewById(R.id.emailEditText);
		ok=(Button)findViewById(R.id.okBtn);
		cancel =(Button)findViewById(R.id.cancelBtn);
		
		ok.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				//progress
				Dialog mProgress=new Dialog(SearchPwd.this,R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(SearchPwd.this),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////
				if(ConnectDB.isNetworkAvailable()) {
					try {
//						Toast.makeText(getBaseContext(), id.getText().toString()+" "+
//											name.getText().toString()+" "+
//											email.getText().toString(),Toast.LENGTH_SHORT).show();
//									
						result=ConnectDB.searchPassword(id.getText().toString(),
											name.getText().toString(),
											email.getText().toString());
						if(result.get(0).equals("FIN")){
							Toast.makeText(getBaseContext(), "�̸��Ϸ� ��й�ȣ�� �߼۵Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
							finish();
						}
						else if(result.get(0).equals("NO"))
							Toast.makeText(getBaseContext(), "�˸´� ������ �ƴմϴ�", Toast.LENGTH_SHORT).show();
						else
							Toast.makeText(getBaseContext(), "ERROR : DB connection error", Toast.LENGTH_SHORT).show();
//						Toast.makeText(getBaseContext(), result, Toast.LENGTH_LONG).show();
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} //try catch
					mProgress.show();
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
					
			}
		});
		
		
		cancel.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				finish();
			}
		});
		
		
	}
}
