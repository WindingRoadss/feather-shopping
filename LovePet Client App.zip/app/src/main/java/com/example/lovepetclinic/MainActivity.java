package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.http.client.ClientProtocolException;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements AnimationListener {

	/* Sliding Menu Variables */
	View menu;
	View mainView;
	boolean menuOut = false;
	AnimParams animParams = new AnimParams();
	/* Sliding Menu Variables */

	/* Sliding Menu Associated Class */
	class ClickListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			System.out.println("onClick " + new Date());
			MainActivity me = MainActivity.this;
			Animation anim;

			int w = mainView.getMeasuredWidth();
			int h = mainView.getMeasuredHeight();
			int left = (int) (mainView.getMeasuredWidth() * 0.6);

			if (!menuOut) {
				// anim = AnimationUtils.loadAnimation(context,
				// R.anim.push_right_out_80);
				anim = new TranslateAnimation(0, left, 0, 0);
				menu.setVisibility(View.VISIBLE);
				animParams.init(left, 0, left + w, h);
			} else {
				// anim = AnimationUtils.loadAnimation(context,
				// R.anim.push_left_in_80);
				anim = new TranslateAnimation(0, -left, 0, 0);
				animParams.init(0, 0, w, h);
			}

			anim.setDuration(500);
			anim.setAnimationListener(me);
			// Tell the animation to stay as it ended (we are going to set the
			// app.layout first than remove this property)
			anim.setFillAfter(true);

			mainView.startAnimation(anim);
		}
	} /* Sliding Menu Associated Class */

	public void onBackPressed() {
		MainActivity me = MainActivity.this;
		int w = mainView.getMeasuredWidth();
		int h = mainView.getMeasuredHeight();
		int left = (int) (mainView.getMeasuredWidth() * 0.6);

		Animation anim = new TranslateAnimation(0, -left, 0, 0);

		if (menuOut) {
			animParams.init(0, 0, w, h);
			anim.setDuration(500);
			anim.setAnimationListener(me);
			// Tell the animation to stay as it ended (we are going to set the
			// app.layout first than remove this property)
			anim.setFillAfter(true);

			mainView.startAnimation(anim);
		} else
			finish();
	}

	/* Main Variables */
	@SuppressLint("NewApi")
	private String id = ConnectDB.getId();
	private String str_user_name = ConnectDB.getUserName();
	private String str_email = ConnectDB.getUserEmail();
	// private String email = ConnectDB.getEmali();
	private Bundle bundle;
	
	
	/* petNumberAvailable */
	boolean petNumberAvailable = false;
	ArrayList<String> pets = null;
	Toast toast = null;
	/* petNumberAvailable */
	
	
	/* Main Variables */

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ConnectDB.setActivity(this); // ��Ʈ��ũ ����Ȯ�� �ϱ� ����
		
		ActionBar actionBar = getActionBar();
		actionBar.hide();

		bundle = new Bundle();

		ConnectDB.addActList(this); // Activity �߰�

		/* Sliding Menu Associated Variables */
		menu = findViewById(R.id.menu);
		mainView = findViewById(R.id.mainView);

		ViewUtils.printView("menu", menu);
		ViewUtils.printView("mainView", mainView);
		/* Sliding Menu Associated Variables */
		
        /*try {
			pets = ConnectDB.getPetNames(id);
			pets.remove(0);

			if(pets.size() == 0) petNumberAvailable = false;
	        else petNumberAvailable = true;
	        
	        ConnectDB.setPetNumberAvailable(petNumberAvailable);
		} catch (ClientProtocolException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}*/

		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(policy);
		// login button

		TextView userName = (TextView) findViewById(R.id.userName);
		Log.d("setTextTest", "str_user_name" + str_user_name);
		userName.setText(str_user_name);
		TextView userEmail = (TextView) findViewById(R.id.userEmail);
		userEmail.setText(str_email);

		// mein menu buttons
		Button petInfoBtn = (Button) findViewById(R.id.petInfoBtn);
		petInfoBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					intent.putExtras(bundle);
					startActivity(intent);
				}
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button reservationBtn = (Button) findViewById(R.id.reservationBtn);
		reservationBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					if(ConnectDB.getPetNumberAvailable()) {
						Intent intent = new Intent(getBaseContext(), Reservation.class);
						intent.putExtras(bundle);
						startActivity(intent);
					}
					else {
						Toast.makeText(getBaseContext(), "��ϵ� ���� �����ϴ�", Toast.LENGTH_SHORT).show(); 
					}
				}
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button reservationViewBtn = (Button) findViewById(R.id.reservationViewBtn);
		reservationViewBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					intent.putExtras(bundle);
					startActivity(intent);
				}
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		Button boardBtn = (Button) findViewById(R.id.boardBtn);
		boardBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(), Board.class);
				startActivity(intent);
			}
		});
		Button clinicInfoBtn = (Button) findViewById(R.id.clinicInfoBtn);
		clinicInfoBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(
						Intent.ACTION_VIEW,
						Uri.parse("http://m.blog.naver.com/sarang795"));
				startActivity(intent);
			}
		});

		Button btnLogOut = (Button) findViewById(R.id.btnLogOut);
		btnLogOut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingLogoutPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnGetPetInfo = (Button) findViewById(R.id.btnGetPetInfo);
		btnGetPetInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					intent.putExtras(bundle);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}
				/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnRsv = (Button) findViewById(R.id.btnRsv);
		btnRsv.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {	
					Intent intent = new Intent(getBaseContext(), Reservation.class);
					intent.putExtras(bundle);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnMyRsvList = (Button) findViewById(R.id.btnMyRsvList);
		btnMyRsvList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					intent.putExtras(bundle);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnQuestion = (Button) findViewById(R.id.btnQuestion);
		btnQuestion.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(), Board.class);
				ConnectDB.deleteActListExceptMain();
				startActivity(intent);
			}
		});

		Button btnHptInfo = (Button) findViewById(R.id.btnHptInfo);
		btnHptInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(), ClinicInfo.class);
				ConnectDB.deleteActListExceptMain();
				startActivity(intent);
			}
		});

		/******** ȸ��Ż��!!!!! ********/
		Button btnWithdraw = (Button) findViewById(R.id.btnWithdraw);
		btnWithdraw.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// pop up
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingWithdrawPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		/******** ȸ��Ż��!!!!! ********/

		/* Sliding Menu Click */
		mainView.findViewById(R.id.btnMyMenu).setOnClickListener(
				new ClickListener());

	}// onCreate()

	/* Sliding Menu Associated Functions */
	void layoutApp(boolean menuOut) {
		System.out.println("layout [" + animParams.left + "," + animParams.top
				+ "," + animParams.right + "," + animParams.bottom + "]");
		mainView.layout(animParams.left, animParams.top, animParams.right,
				animParams.bottom);
		// Now that we've set the app.layout property we can clear the
		// animation, flicker avoided :)
		mainView.clearAnimation();
	}

	@Override
	public void onAnimationEnd(Animation animation) {
		System.out.println("onAnimationEnd");
		ViewUtils.printView("menu", menu);
		ViewUtils.printView("mainView", mainView);
		menuOut = !menuOut;
		if (!menuOut) {
			menu.setVisibility(View.INVISIBLE);
		}
		layoutApp(menuOut);
	}

	@Override
	public void onAnimationRepeat(Animation animation) {
		System.out.println("onAnimationRepeat");
	}

	@Override
	public void onAnimationStart(Animation animation) {
		System.out.println("onAnimationStart");
	}

	static class AnimParams {
		int left, right, top, bottom;

		void init(int left, int top, int right, int bottom) {
			this.left = left;
			this.top = top;
			this.right = right;
			this.bottom = bottom;
		}
	}
	/* Sliding Menu Associated Functions */
}
