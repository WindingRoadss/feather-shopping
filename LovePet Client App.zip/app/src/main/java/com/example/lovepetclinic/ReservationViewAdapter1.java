package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ReservationViewAdapter1 extends BaseAdapter {
    Context ctx;
    LayoutInflater lInflater;
    ArrayList<ReservationViewItem1> objects;
    ArrayList<String> pets = null;
    String id = ConnectDB.getId(); 
    Bundle bundle;
    

    ReservationViewAdapter1(Context context, ArrayList<ReservationViewItem1> products) {
        ctx = context;
        objects = products;
        lInflater = (LayoutInflater) ctx
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return objects.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = lInflater.inflate(R.layout.reservation_view_item, parent, false);
        }
        final int po=position;
        final ReservationViewItem1 p = getProduct(position);
        
        
        String text=p.getYear()+"."+p.getMonth()+"."+p.getDay()+" "+p.getTime()+"�� - �� �̸� : "+p.getPet_name()+"\n "+
        			p.getDetail();
        ((TextView) view.findViewById(R.id.reservationViewTextView)).setText(text);
        ((Button) view.findViewById(R.id.visitedButton))
        		.setOnClickListener(new OnClickListener(){
						public void onClick(View v) {//progress
							if(ConnectDB.isNetworkAvailable()) {
								bundle = new Bundle();
								bundle.putString("pet_name", p.getPet_name());
								bundle.putString("year", p.getYear());
								bundle.putString("month", p.getMonth());
								bundle.putString("day", p.getDay());
								bundle.putString("time", p.getTime());
								bundle.putString("detail", p.getDetail());
								Intent intent = new Intent(ctx, 
										ReservationView1DeletePopup.class);//LoginActivity.class);
								intent.putExtras(bundle);
								 ctx.startActivity(intent);
							} /* connection Ȯ�� */
							else
								Toast.makeText(ctx, "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
						}
        		});

        return view;
    }

    ReservationViewItem1 getProduct(int position) {
        return ((ReservationViewItem1) getItem(position));
    }


}
