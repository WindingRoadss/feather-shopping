package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

//ȣ��-���ι�ư��ġ ��
public class PetInfo1DeletePopup extends Activity {
	Bundle bundle;
	String id = ConnectDB.getId();
	String pet_name;
	
	/* petNumberAvailable */
	boolean petNumberAvailable = false;
	ArrayList<String> pets = null;
	Toast toast = null;
	/* petNumberAvailable */
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		ConnectDB.addActList(this); // Activity �߰�
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.pet_info1_delete_popup);//xml���� �̸�

		bundle = getIntent().getExtras();
		pet_name = bundle.getString("pet_name");
		
		
		Button btn1 = (Button)findViewById(R.id.okBtn);//xml���� ok��ưid
		btn1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// delete operation
				String result;
				if(ConnectDB.isNetworkAvailable()) {
					try {
						result = ConnectDB.deletePet(id, pet_name);
						if (result.equals("FIN")) {
							Toast.makeText(getBaseContext(), "���������� �����Ͽ����ϴ�.",
									Toast.LENGTH_SHORT).show();
							pets = ConnectDB.getPetNames(id);
							pets.remove(0);

							if(pets.size() == 0) petNumberAvailable = false;
					        else petNumberAvailable = true;
					        
					        ConnectDB.setPetNumberAvailable(petNumberAvailable);
							// refresh�� ���� intent
							Intent intent = new Intent();
							intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							setResult(RESULT_OK, intent);
							finish();
						} else if (result.equals("NO"))
							Toast.makeText(getBaseContext(), "���������� �����Ͽ����ϴ�.",
									Toast.LENGTH_SHORT).show();
						else
							Toast.makeText(getBaseContext(),
									"ERROR : DB connection error",
									Toast.LENGTH_SHORT).show();
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}		
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}	
        });
		
		Button btn2 = (Button)findViewById(R.id.cancelBtn);//cancel btn
		btn2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();		
			}	
        });
	}

	
}
