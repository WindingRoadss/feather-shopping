package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;


public class PetInfo4MdcRecView extends Activity {

	
	private ListView petLogList;
	private ArrayList<String> arrayList;
	private ArrayAdapter<String> adapter;
	private String id = ConnectDB.getId();
	private String str_pet_name;
	Bundle bundle;
	private ArrayList<String> arrayViewRsvMdcRec;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pet_info4_logview);
		
		ConnectDB.addActList(this); // Activity �߰�
		
		bundle= getIntent().getExtras();
		str_pet_name = bundle.getString("pet_name");
		
		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_mdc_rec_view_bar); 
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		//progress
		Dialog mProgress=new Dialog(PetInfo4MdcRecView.this,R.style.MyDialog);
		mProgress.setCancelable(true);
		mProgress.addContentView(new ProgressBar(PetInfo4MdcRecView.this),
								new LayoutParams(LayoutParams.WRAP_CONTENT,
												LayoutParams.WRAP_CONTENT));
		mProgress.show();
		////
		//add
		arrayList= new ArrayList<String>();
		try { //����� result�� ���� listview�� �� �����
			Log.d("���Ẹ��", "id : " + id + " " + "pet name : " + str_pet_name);
			arrayViewRsvMdcRec = ConnectDB.viewMdcRecord(id, str_pet_name); // ���� ������ ����
    		Log.d("���Ẹ��", "arrayViewRsvMdcRec");
    		
		} catch (ClientProtocolException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		
		addPetNameToPetLogList();
		mProgress.dismiss();
		adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);
		
		
		
		petLogList= (ListView)findViewById(R.id.petLogListView);
		petLogList.setAdapter(adapter);
		petLogList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		
		petLogList.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String petName=(String)adapter.getItem(position);
				Bundle bundle=new Bundle();
				bundle.putString("petName",petName);
			}
			
		});
		
	}
	
	void addPetNameToPetLogList(){
		//dbdb getPetName
//		arrayList.add("2013"+"��"+"8"+"��"+"10"+"��"+" : "+"�ʶ���"+" "+"���Ⱑ ������");
//		arrayList.add("2013"+"��"+"10"+"��"+"1"+"��"+" : "+"�̹�"+" "+"�������� 1");
//		arrayList.add("2014"+"��"+"1"+"��"+"4"+"��"+" : "+"����"+"���� ������");
		int columnNum = 1; //�迭 index ����
		Log.d("������", "������ ����Ʈ ����" + String.valueOf(arrayViewRsvMdcRec.size()));
		for(int i = 0; i < (arrayViewRsvMdcRec.size() - 1) / 6; i++) {
			Log.d("������", "������ ����Ʈ add");
//			arrayList.add(new ReservationViewItem1(id,arrayViewRsvHsp.get(1 + columnNum) + "�� ",arrayViewRsvHsp.get(2 + columnNum) + "�� "
//					   ,arrayViewRsvHsp.get(3 + columnNum) + "�� ",arrayViewRsvHsp.get(4 + columnNum) + "�� : ",
//					   	arrayViewRsvHsp.get(0 + columnNum) + " ",arrayViewRsvHsp.get(5 + columnNum)));
			arrayList.add(arrayViewRsvMdcRec.get(1 + columnNum) + "." + arrayViewRsvMdcRec.get(2 + columnNum) + "." +
						arrayViewRsvMdcRec.get(3 + columnNum) + " " + arrayViewRsvMdcRec.get(4 + columnNum) + "�� - �� �̸� : " +
						arrayViewRsvMdcRec.get(0 + columnNum) + "\n " + arrayViewRsvMdcRec.get(5 + columnNum));
			columnNum = columnNum + 6; //�迭 index ����
		}
	}
}
