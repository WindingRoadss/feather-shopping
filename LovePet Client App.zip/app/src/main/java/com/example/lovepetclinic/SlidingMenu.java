package com.example.lovepetclinic;

import java.util.Date;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation.AnimationListener;

public class SlidingMenu {

	/* Sliding Menu Variables */
	private View menu;
	private View mainView;
	private boolean menuOut = false;
	private AnimParams animParams = new AnimParams();
	private ClickListener clickListener;
	AniListenerActivity aniListenerAct;
	/* Sliding Menu Variables */
//
//	public void setContextSM(AniListenerActivity ala) {
//		aniListenerAct = ala;
//	}
//	
	public SlidingMenu(AniListenerActivity c) {
		clickListener = new ClickListener(c);
	}
	
	public ClickListener getClickListener() {
		return clickListener;
	}
	
	public View getMainView() {
		return mainView;
	}

	public void setMainView(View mainView) {
		this.mainView = mainView;
	}

	public boolean getMenuOut() {
		return menuOut;
	}

	public void setMenuOut(boolean menuOut) {
		this.menuOut = menuOut;
	}

	public AnimParams getAnimParams() {
		return animParams;
	}

	public void setAnimParams(AnimParams animParams) {
		this.animParams = animParams;
	}

	public void setMenu(View menu) {
		this.menu = menu;
	}
	
	public View getMenu() {
		return menu;
	}

	/* Sliding Menu Associated Class */
	class ClickListener implements OnClickListener {
		Context c;
		Activity a;
		AniListenerActivity ala;
		
		public ClickListener(AniListenerActivity ala) {
			this.ala = ala;
			aniListenerAct = ala;
		}
		
        @Override
        public void onClick(View v) {
            System.out.println("onClick " + new Date());
            Context context = ala.getBaseContext();
            Animation anim;

            int w = mainView.getMeasuredWidth();
            int h = mainView.getMeasuredHeight();
            int left = (int) (mainView.getMeasuredWidth() * 0.6);

            if (!menuOut) {
                // anim = AnimationUtils.loadAnimation(context, R.anim.push_right_out_80);
                anim = new TranslateAnimation(0, left, 0, 0);
                menu.setVisibility(View.VISIBLE);
                animParams.init(left, 0, left + w, h);
            } else {
                // anim = AnimationUtils.loadAnimation(context, R.anim.push_left_in_80);
                anim = new TranslateAnimation(0, -left, 0, 0);
                animParams.init(0, 0, w, h);
            }

            anim.setDuration(500);
            //anim.setAnimationListener(context.getClass().);
            
            anim.setAnimationListener(ala);
            
            //Tell the animation to stay as it ended (we are going to set the app.layout first than remove this property)
            anim.setFillAfter(true);

            mainView.startAnimation(anim);
        }
    } /* Sliding Menu Associated Class */
	
	
	/* Sliding Menu Associated Functions */
	void layoutApp(boolean menuOut) {
        System.out.println("layout [" + animParams.left + "," + animParams.top + "," + animParams.right + ","
                + animParams.bottom + "]");
        mainView.layout(animParams.left, animParams.top, animParams.right, animParams.bottom);
        //Now that we've set the app.layout property we can clear the animation, flicker avoided :)
        mainView.clearAnimation();
    }

	
    private class AnimParams {
        int left, right, top, bottom;

        void init(int left, int top, int right, int bottom) {
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }
    }
    /* Sliding Menu Associated Functions */
    
    public int onBackFunction() {
    	/* MainActivity me = MainActivity.this;
        Context context = me;
        int w = mainView.getMeasuredWidth();
		int h = mainView.getMeasuredHeight();
		int left = (int) (mainView.getMeasuredWidth() * 0.6);
		
        Animation anim = new TranslateAnimation(0, -left, 0, 0);

		if(menuOut) {
		    animParams.init(0, 0, w, h);
		    anim.setDuration(500);
	        anim.setAnimationListener(me);
	        //Tell the animation to stay as it ended (we are going to set the app.layout first than remove this property)
	        anim.setFillAfter(true);

	        mainView.startAnimation(anim);
		}
		else finish();
    	 * */
    	int w = getMainView().getMeasuredWidth();
 		int h = getMainView().getMeasuredHeight();
		int left = (int) (getMainView().getMeasuredWidth() * 0.6);
		
        Animation anim = new TranslateAnimation(0, -left, 0, 0);
        
		if(getMenuOut()) {
			//Context context = ala.getBaseContext();
			animParams.init(0, 0, w, h);
			anim.setDuration(500);
	        anim.setAnimationListener(aniListenerAct);
	        //Tell the animation to stay as it ended (we are going to set the app.layout first than remove this property)
	        anim.setFillAfter(true);

	        getMainView().startAnimation(anim);
	        return 1;
		}
		else return 0;
    }
}
