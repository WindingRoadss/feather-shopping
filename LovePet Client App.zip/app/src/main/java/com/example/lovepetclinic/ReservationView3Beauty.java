package com.example.lovepetclinic;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.Dialog;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.CalendarView.OnDateChangeListener;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ReservationView3Beauty extends Fragment{
     
	private ListView petLogList;
	private ArrayList<ReservationViewItem3> arrayList;
	private ReservationViewAdapter3 adapter;
    
	private String id = ConnectDB.getId();
	private ArrayList<String> arrayViewRsvBty;
 
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
    	//progress
    	if(ConnectDB.isNetworkAvailable()) {
			Dialog mProgress=new Dialog(getActivity(),R.style.MyDialog);
			mProgress.setCancelable(true);
			mProgress.addContentView(new ProgressBar(getActivity()),
									new LayoutParams(LayoutParams.WRAP_CONTENT,
													LayoutParams.WRAP_CONTENT));
			mProgress.show();
			////
	    	try{
	    		arrayViewRsvBty = ConnectDB.viewRsvBty(id);
	    		Log.d("�̿뿹��", "arrayViewRsvBty");
	    	} catch (ClientProtocolException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	    	mProgress.dismiss();
    	} /* connection Ȯ�� */
		else
			 Toast.makeText(getActivity(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
					 							Toast.LENGTH_SHORT).show();
	    	
    	View view = inflater.inflate( R.layout.reservation_view_tab, container, false );
    	//id=getActivity().getIntent().getExtras().getString("id");
    	id = ConnectDB.getId();
    	//add
		arrayList = new ArrayList<ReservationViewItem3>();
		addPetNameToPetLogList();
		adapter = new ReservationViewAdapter3(getActivity(),arrayList);
		
		
		
		petLogList= (ListView)view.findViewById(R.id.petLogListView);
		
		
		/* Scroll ���� */
		petLogList.removeHeaderView(view);
		petLogList.removeFooterView(view);
		/* Scroll ���� */
		
		
		petLogList.setAdapter(adapter);
		petLogList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		
		//�� ��������?
		petLogList.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String petName=(String)adapter.getItem(position);
				Bundle bundle=new Bundle();
				bundle.putString("petName",petName);
			}
			
		});
	
		return view;
		
	}
	
	void addPetNameToPetLogList(){
		//dbdb getPetName
	
		int columnNum = 1;
		for(int i = 0; i < (arrayViewRsvBty.size() - 1) / 6; i++) {
			Log.d("�̿뿹��", "�̿뿹�� ����Ʈ add");

			arrayList.add(new ReservationViewItem3(id,arrayViewRsvBty.get(1 + columnNum),arrayViewRsvBty.get(2 + columnNum)
												   ,arrayViewRsvBty.get(3 + columnNum),arrayViewRsvBty.get(4 + columnNum),
												   arrayViewRsvBty.get(0 + columnNum),arrayViewRsvBty.get(5 + columnNum)));
			columnNum = columnNum + 6; //�迭 index ����
		}
	}


}