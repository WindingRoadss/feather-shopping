package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

//ȣ��-���ι�ư��ġ ��
public class SlidingWithdrawPopup extends Activity {
	String id = ConnectDB.getId();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	//	ConnectDB.addActList(this); // Activity �߰�
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.sliding_withdraw_popup);//xml���� �̸�

	
		Button btn1 = (Button)findViewById(R.id.okBtn);//xml���� ok��ưid
		btn1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// delete operation
				try {
					ArrayList<String> result=ConnectDB.withDraw(id);
					ConnectDB.deleteAllActList();
					if(result.get(0).equals("FIN"))
						Toast.makeText(getBaseContext(), "Ż��Ǿ����ϴ�", Toast.LENGTH_SHORT).show();
					else if(result.get(0).equals("NO"))
						Toast.makeText(getBaseContext(), "Ż�� ó���� ���� �ʾҽ��ϴ�", Toast.LENGTH_SHORT).show();
					else
						Toast.makeText(getBaseContext(), "ERROR : DB result error", Toast.LENGTH_SHORT).show();
					Intent intent = new Intent(getBaseContext(), LoginActivity.class);
					startActivity(intent);
					finish();
						
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			}	
        });
		
		Button btn2 = (Button)findViewById(R.id.cancelBtn);//cancel btn
		btn2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();		
			}	
        });
	}

	
}
