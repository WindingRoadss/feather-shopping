package com.example.lovepetclinic;

public class ReservationViewItem2 {
	private String id;
	private String in_year;
	private String in_month;
	private String in_day;
	private String out_year;
	private String out_month;
	private String out_day;
	private String pet_name;
	private String approval;
	
	//constructor
	ReservationViewItem2(String id,String in_year,String in_month,String in_day,String out_year,
			String out_month, String out_day, String pet_name, String approval){
		this.id=id;
		this.in_year=in_year;
		this.in_month=in_month;
		this.in_day=in_day;
		this.out_year=out_year;
		this.out_month=out_month;
		this.out_day=out_day;
		this.pet_name=pet_name;
		this.approval=approval;
		
	}
	

	public String getId(){
		return id;
	}
	public void setId(String id){
		this.id=id;
	}
	public String getIn_year() {
		return in_year;
	}
	public void setIn_year(String in_year) {
		this.in_year = in_year;
	}
	public String getIn_month() {
		return in_month;
	}
	public void setIn_month(String in_month) {
		this.in_month = in_month;
	}
	public String getIn_day() {
		return in_day;
	}
	public void setIn_day(String in_day) {
		this.in_day = in_day;
	}
	public String getOut_year() {
		return out_year;
	}
	public void setOut_year(String out_year) {
		this.out_year = out_year;
	}
	public String getOut_month() {
		return out_month;
	}
	public void setOut_month(String out_month) {
		this.out_month = out_month;
	}
	public String getOut_day() {
		return out_day;
	}
	public void setOut_day(String out_day) {
		this.out_day = out_day;
	}
	public String getPet_name() {
		return pet_name;
	}
	public void setPet_name(String pet_name) {
		this.pet_name = pet_name;
	}
	public String getApproval() {
		return approval;
	}
	public void setApproval(String approval) {
		this.approval = approval;
	}
	
	
	
	
	
}
