package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class LoginActivity extends Activity {
	@SuppressLint("NewApi")
	private String id;
	private ArrayList<String> arrayMemberIdName; //회원의 ID와 이름 저장
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		
		ConnectDB.setActivity(this); // 네트워크 연결확인 하기 위한
		
		ConnectDB.deleteAllActList(); // 남아있는 activity 삭제하고 시작
		
		ActionBar actionBar = getActionBar();
		actionBar.hide();
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(policy);
		

		// login button
		Button loginBtn = (Button) findViewById(R.id.btnLogin);

		loginBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				//progress
				Dialog mProgress=new Dialog(LoginActivity.this,R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(LoginActivity.this),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////
				EditText idTV = (EditText) findViewById(R.id.edtId);
				id = String.valueOf(idTV.getText());
				EditText passwordTV = (EditText) findViewById(R.id.edtPwd);
				String password = String.valueOf(passwordTV.getText());
				//String result = null;

				if(ConnectDB.isNetworkAvailable()) {
				// add dbdb : getMember(String id,String password)
					try {
						arrayMemberIdName = ConnectDB.login(id, password);
						Log.d("set ID Test", "try 전0" + arrayMemberIdName.get(0));
						Log.d("set ID Test", "try 전1");
						if(arrayMemberIdName.get(0) == "OK") { //login 성공
							ConnectDB.setId(id);
							ConnectDB.setName(arrayMemberIdName.get(1));
							ConnectDB.setEmail(arrayMemberIdName.get(2));
							Intent intent = new Intent(getBaseContext(), MainActivity.class);
							startActivity(intent);
							finish();
						}
						else{
							Toast.makeText(getBaseContext(), "로그인에 실패하였습니다" ,Toast.LENGTH_LONG).show();
						}
					} catch (ClientProtocolException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					mProgress.dismiss();
				}
				else
					 Toast.makeText(getBaseContext(), "네트워크 연결 상태를 확인하세요", Toast.LENGTH_SHORT).show();
			}

		});

		/*loginBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
				//progress
				Dialog mProgress=new Dialog(LoginActivity.this,R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(LoginActivity.this),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////
				EditText idTV = (EditText) findViewById(R.id.edtId);
				id = String.valueOf(idTV.getText());
				EditText passwordTV = (EditText) findViewById(R.id.edtPwd);
				String password = String.valueOf(passwordTV.getText());
				//String result = null;
				
				if(ConnectDB.isNetworkAvailable()) {
				// add dbdb : getMember(String id,String password)
					try {
						arrayMemberIdName = ConnectDB.login(id, password);
						Log.d("set ID Test", "try 전0" + arrayMemberIdName.get(0));
						Log.d("set ID Test", "try 전1");
						if(arrayMemberIdName.get(0) == "OK") { //login 성공
							*//* id, pwe 아무것도 넣지 않았을 때는 안드로이드에서 처리해야한다 *//*
							*//* 또한 잘못된 id, pwd일 경우에도 처리해줘야 한다 *//*
							ConnectDB.setId(id);
							ConnectDB.setName(arrayMemberIdName.get(1));
							ConnectDB.setEmail(arrayMemberIdName.get(2));
							Intent intent = new Intent(getBaseContext(), MainActivity.class);
							startActivity(intent);
							finish();
						}
						else{
							Toast.makeText(getBaseContext(), "로그인에 실패하였습니다" ,Toast.LENGTH_LONG).show();
						}
					} catch (ClientProtocolException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					mProgress.dismiss();
				}  *//* connection 확인 *//*
				else
					 Toast.makeText(getBaseContext(), "네트워크 연결 상태를 확인하세요", Toast.LENGTH_SHORT).show();
			}

		});*/
		// get member button
		Button getMemberBtn = (Button) findViewById(R.id.btnMemberJoin);
		getMemberBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(), GetMember.class);
				startActivity(intent);
			}
		});
		
		
		Button btnSearchPwd = (Button) findViewById(R.id.btnSearchPwd);
		btnSearchPwd.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(), SearchPwd.class);
				startActivity(intent);
			}
		});
		
		Button btnHospitalInfo = (Button)findViewById(R.id.btnHptInfo);
		btnHospitalInfo.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				Intent intentHospInfo = new Intent(getBaseContext(), ClinicInfo.class);
				startActivity(intentHospInfo);
			}
		});

	}// onCreate()


}
