package com.example.lovepetclinic;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

public class IntroActivity extends Activity {
	// IntroActivity ù ȭ�� ��Ƽ��Ƽ
	public void onBackPressed() { }

	// �ڷ� ���� ��ư ��Ȱ��ȭ
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.intro);
		
		/* ActionBar Style set */
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.hide();
		/* ActionBar Style set */
		
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			public void run() {
				Intent intent = new Intent(IntroActivity.this, LoginActivity.class);
				startActivity(intent);
				overridePendingTransition(R.anim.fade, R.anim.hold);
				// fade in - fade out ȿ��
				finish();
			}
		}, 2000); // 2�� �� �ڵ� ����
	}
}
