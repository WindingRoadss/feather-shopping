package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Reservation3BeautyNext extends AniListenerActivity {

	String id= ConnectDB.getId();
	String user_name=ConnectDB.getUserName();
	TextView date;
	Bundle bundle;
	
	String year;
	String month;
	String day;
	String time;
	
	String petName;
	String userName="name";
	//spinner
	//private String[] pets={"������","������","�浿��"};
	private String[] pets;

	
	EditText detail;
	
	public void onBackPressed() { //�ڷ� ���� ��ư
		//progress
		Dialog mProgress=new Dialog(Reservation3BeautyNext.this,R.style.MyDialog);
		mProgress.setCancelable(true);
		mProgress.addContentView(new ProgressBar(Reservation3BeautyNext.this),
								new LayoutParams(LayoutParams.WRAP_CONTENT,
												LayoutParams.WRAP_CONTENT));
		mProgress.show();
		////
		try {
			
			if(sliding_menu.onBackFunction() == 0) { // ���̵� �޴��� ��Ÿ�� ���� ���� ���¸� finish
				ArrayList<String> result=ConnectDB.deleteIsReservedIngBty(year, month, day, time);
				Log.d("�̿�test onBackPressed", "OnBackPressed �۵� Ȯ��" + result.get(0));
				finish();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		mProgress.dismiss();
		
	}
	
	/* sliding menu�� �̸��� �̸��� ���� */
	private String str_user_name = ConnectDB.getUserName();
	private String str_email = ConnectDB.getUserEmail();
	/* sliding menu�� �̸��� �̸��� ���� */
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reservation3_beauty1_next);
		
		ConnectDB.addActList(this); // Activity �߰�
		ConnectDB.setActivity(this); // ��Ʈ��ũ ����Ȯ�� �ϱ� ����
		//bundle
		bundle =getIntent().getExtras();
		year=bundle.getString("year");
		month=bundle.getString("month");
		day=bundle.getString("day");
		time=bundle.getString("time");
		//date
		date=(TextView)findViewById(R.id.clinicReservationDate);
		date.setText(year+" / "+month+" / "+day+" ( "+time+"�� )");
		
		/* Sliding Menu options */
		sliding_menu = new SlidingMenu(this);
		
		sliding_menu.setMenu(findViewById(R.id.menu));
		sliding_menu.setMainView(findViewById(R.id.mainView));
		/* Sliding Menu options */
		
		/* �׼ǹ� ��Ÿ�� ���� */
		Drawable[] actionBarBackGrnd = new Drawable[1]; 
		actionBarBackGrnd[0] = this.getResources().getDrawable(R.drawable.img_hptrsv_bar); 
		getActionBar().setTitle("");
		getActionBar().setDisplayShowHomeEnabled(false);
		ActionBar actionBar = getActionBar();
		actionBar.setBackgroundDrawable(actionBarBackGrnd[0]);
		/* �׼ǹ� ��Ÿ�� ���� */
		
		/* userName and userEmail Setting  */
		TextView userName = (TextView)findViewById(R.id.userName);
		Log.d("setTextTest", "str_user_name" + str_user_name);
		userName.setText(str_user_name);
		TextView userEmail = (TextView)findViewById(R.id.userEmail);
		userEmail.setText(str_email);
		/* userName and userEmail Setting  */
		
		try {
			ArrayList<String> tempList = ConnectDB.getPetNames(id);
			tempList.remove(0);
			pets=tempList.toArray(new String[tempList.size()]);
			Log.d("�̿�test", Integer.toString(tempList.size()));
		} catch (ClientProtocolException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		//spinner
		ArrayAdapter<String> petsList = new ArrayAdapter(this, R.layout.spinner_item, pets);
		petsList.setDropDownViewResource(R.layout.spinner_dropdown);
		Spinner petsSpinner=(Spinner)findViewById(R.id.pet_spinner);
		petsSpinner.setAdapter(petsList);
		petsSpinner.setOnItemSelectedListener(new OnItemSelectedListener(){
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				TextView tv=(TextView)view;
				petName=String.valueOf(tv.getText());
				//Toast.makeText(getBaseContext(), String.valueOf(tv.getText()),Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				
			}
		});
		
		//EditText
		detail=(EditText)findViewById(R.id.reservationEditText);
		

		/* ���̵�޴� ��ư�� ��� ���� */
		Button btnLogOut = (Button) findViewById(R.id.btnLogOut);
		btnLogOut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingLogoutPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnGetPetInfo = (Button) findViewById(R.id.btnGetPetInfo);
		btnGetPetInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), PetInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnRsv = (Button) findViewById(R.id.btnRsv);
		btnRsv.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					if(ConnectDB.getPetNumberAvailable()) {
						Intent intent = new Intent(getBaseContext(), Reservation.class);
						ConnectDB.deleteActListExceptMain();
						startActivity(intent);
					}
					else {
						Toast.makeText(getBaseContext(), "��ϵ� ���� �����ϴ�", Toast.LENGTH_SHORT).show(); 
					}
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnMyRsvList = (Button) findViewById(R.id.btnMyRsvList);
		btnMyRsvList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(),
							ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		Button btnQuestion = (Button) findViewById(R.id.btnQuestion);
		btnQuestion.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), Board.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
				
			}
		});

		Button btnHptInfo = (Button) findViewById(R.id.btnHptInfo);
		btnHptInfo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), ClinicInfo.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});

		/******** ȸ��Ż��!!!!! ********/
		Button btnWithdraw = (Button) findViewById(R.id.btnWithdraw);
		btnWithdraw.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// pop up
				if(ConnectDB.isNetworkAvailable()) {
					Intent intent = new Intent(getBaseContext(), 
							SlidingWithdrawPopup.class);//LoginActivity.class);
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
			}
		});
		/******** ȸ��Ż��!!!!! ********/

		sliding_menu.getMainView().findViewById(R.id.btnMyMenu)
				.setOnClickListener(sliding_menu.getClickListener());
		/* ���̵�޴� ��ư�� ��� ���� */		
		
		//button
		Button okBtn=(Button)findViewById(R.id.okBtn);
		okBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				//progress
				if(ConnectDB.isNetworkAvailable()) {
					bundle = new Bundle();
//					ArrayList<String> result=ConnectDB.reserveHospital(year, month, day, time, 
//							petName, id, user_name, detail.getText().toString());
					
					bundle.putString("year", year);
					bundle.putString("month", month);
					bundle.putString("day", day);
					bundle.putString("time", time);
					bundle.putString("pet_name", petName);
					bundle.putString("user_name", ConnectDB.getUserName());
					bundle.putString("toDo", detail.getText().toString());
					Intent intent = new Intent(getBaseContext(), 
							ReservationConfirmBty.class);//LoginActivity.class);
					intent.putExtras(bundle);
					startActivity(intent);
				}/* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
							 		Toast.LENGTH_SHORT).show();
			}
			
		});
		
		Button cancleBtn=(Button)findViewById(R.id.cancleBtn);
		cancleBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				//progress
				Dialog mProgress=new Dialog(Reservation3BeautyNext.this,R.style.MyDialog);
				mProgress.setCancelable(true);
				mProgress.addContentView(new ProgressBar(Reservation3BeautyNext.this),
										new LayoutParams(LayoutParams.WRAP_CONTENT,
														LayoutParams.WRAP_CONTENT));
				mProgress.show();
				////
				try {
					ArrayList<String> result=ConnectDB.deleteIsReservedIngBty(year, month, day, time);
					Log.d("�̿�test onBackPressed", "OnBackPressed �۵� Ȯ��" + result.get(0));
					finish();
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				mProgress.dismiss();
			}
			
		});
		
		
		
	}
}
