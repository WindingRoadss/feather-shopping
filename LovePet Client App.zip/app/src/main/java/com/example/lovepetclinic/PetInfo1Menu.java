package com.example.lovepetclinic;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PetInfo1Menu extends Activity {

	Bundle bundle;
	String id = ConnectDB.getId();
	String pet_name;
	private final static int REFRESH_RESULT = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		ConnectDB.addActList(this); // Activity �߰�
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.pet_info1_menu);

		bundle = getIntent().getExtras();
		pet_name = bundle.getString("pet_name");

		// �������� ��ư
		Button viewPetInfoBtn = (Button) findViewById(R.id.viewPetInfoBtn);
		viewPetInfoBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(getBaseContext(), PetInfo3View.class);
				intent.putExtras(bundle);
				startActivity(intent);

			}

		});
		// �������� ��ư
		Button editPetInfoBtn = (Button) findViewById(R.id.editPetInfoBtn);
		editPetInfoBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(getBaseContext(),
						PetInfo5Modify.class);
				intent.putExtras(bundle);
				startActivityForResult(intent, REFRESH_RESULT);
			}

		});
		// ���Ẹ�� ��ư
		Button viewLogPetInfoBtn = (Button) findViewById(R.id.viewlogPetInfoBtn);
		viewLogPetInfoBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(getBaseContext(), PetInfo4MdcRecView.class);
				Bundle bundle=new Bundle();
				bundle.putString("id", id);
				bundle.putString("pet_name", pet_name);
				intent.putExtras(bundle);
				startActivity(intent);
			}

		});
		
		// ��������
		Button deletePetInfoBtn = (Button) findViewById(R.id.deletePetInfoBtn);
		deletePetInfoBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(), PetInfo1DeletePopup.class);
				//Intent intent = new Intent(getBaseContext(), PetInfo1Menu.class);
				bundle.putString("id", id);
				bundle.putString("pet_name", pet_name);
				intent.putExtras(bundle);
				startActivityForResult(intent, REFRESH_RESULT);
				
			}

		});

		/* �������� */
//		Button deletePetInfoBtn = (Button) findViewById(R.id.deletePetInfoBtn);
//		deletePetInfoBtn.setOnClickListener(new OnClickListener() {
//			String result;
//
//			public void onClick(View v) {
//				try {
//					result = ConnectDB.deletePet(id, pet_name);
//					if (result.equals("FIN")) {
//						Toast.makeText(getBaseContext(), "���������� �����Ͽ����ϴ�.",
//								Toast.LENGTH_SHORT).show();
//						// refresh�� ���� intent
//						Intent intent = new Intent();
//						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//						setResult(RESULT_OK, intent);
//						finish();
//					} else if (result.equals("NO"))
//						Toast.makeText(getBaseContext(), "���������� �����Ͽ����ϴ�.",
//								Toast.LENGTH_SHORT).show();
//					else
//						Toast.makeText(getBaseContext(),
//								"ERROR : DB connection error",
//								Toast.LENGTH_SHORT).show();
//				} catch (ClientProtocolException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//
//		});

	}

	// refresh�� ���� resultó�� �κ�
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		switch (requestCode) {
		case REFRESH_RESULT:

			if (resultCode == RESULT_OK) {
				Intent intent = new Intent();
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				setResult(RESULT_OK, intent);
				finish();
			}
			break;
		}
	}
}
