package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ReservationViewAdapter3 extends BaseAdapter {
    Context ctx;
    LayoutInflater lInflater;
    ArrayList<ReservationViewItem3> objects;
    String id=ConnectDB.getId();
    Bundle bundle = new Bundle();
    ReservationViewAdapter3(Context context, ArrayList<ReservationViewItem3> products) {
        ctx = context;
        objects = products;
        lInflater = (LayoutInflater) ctx
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return objects.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = lInflater.inflate(R.layout.reservation_view_item3, parent, false);
        }
        final int po=position;
        final ReservationViewItem3 p = getProduct(position);
        String text=p.getYear()+"."+p.getMonth()+"."+p.getDay()+" "+p.getTime()+"�� - �� �̸� : "+p.getPet_name()+"\n "+
        			p.getDetail();
        ((TextView) view.findViewById(R.id.reservationViewTextView)).setText(text);
        ((Button) view.findViewById(R.id.reservationViewDeleteButton))
        		.setOnClickListener(new OnClickListener(){
						public void onClick(View v) {
							//progress
//							Dialog mProgress=new Dialog(ctx,R.style.MyDialog);
//							mProgress.setCancelable(true);
//							mProgress.addContentView(new ProgressBar(ctx),
//													new LayoutParams(LayoutParams.WRAP_CONTENT,
//																	LayoutParams.WRAP_CONTENT));
//							mProgress.show();
//							////
//							
//							try {
//								//pop up!!!!!!!!!!!
//								ArrayList<String> result=ConnectDB.deleteRsvBty(id, p.getPet_name(), p.getYear(),p.getMonth()
//										,p.getDay(),p.getTime());
//								
//								if(result.get(0).equals("FIN"))
//									Toast.makeText(ctx, "�����Ǿ����ϴ�", Toast.LENGTH_SHORT).show();
//								else 
//									Toast.makeText(ctx, "ERROR : deleteRsvBty", Toast.LENGTH_SHORT).show();
//								//------------------------------------------------------------------------addPetNameToPetLogList();
//							} catch (ClientProtocolException e) {
//								// TODO Auto-generated catch block
//								e.printStackTrace();
//							} catch (IOException e) {
//								// TODO Auto-generated catch block
//								e.printStackTrace();
//							}
//							mProgress.dismiss();
//						}
//						pet_name = bundle.getString("pet_name");
//						year = bundle.getString("year");
//						month = bundle.getString("month");
//						day = bundle.getString("day");
//						time = bundle.getString("time");
//						detail = bundle.getString("detail");
							if(ConnectDB.isNetworkAvailable()) {
								bundle = new Bundle();
								bundle.putString("pet_name", p.getPet_name());
								bundle.putString("year", p.getYear());
								bundle.putString("month", p.getMonth());
								bundle.putString("day", p.getDay());
								bundle.putString("time", p.getTime());
								bundle.putString("detail", p.getDetail());
								Intent intent = new Intent(ctx, 
										ReservationView3DeletePopup.class);//LoginActivity.class);
								intent.putExtras(bundle);
								 ctx.startActivity(intent);
							} /* connection Ȯ�� */
							else
								Toast.makeText(ctx, "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
						}
						
        		});

        return view;
    }

    ReservationViewItem3 getProduct(int position) {
        return ((ReservationViewItem3) getItem(position));
    }


}
