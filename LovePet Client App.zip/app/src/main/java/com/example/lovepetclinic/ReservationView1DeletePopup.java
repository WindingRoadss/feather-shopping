package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

//ȣ��-���ι�ư��ġ ��
public class ReservationView1DeletePopup extends Activity {
	Bundle bundle = new Bundle();
	String id=ConnectDB.getId();
    String pet_name;
    String year;
    String month;
    String day;
    String time;
    String detail;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		ConnectDB.addActList(this); // Activity �߰�
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.reservation_view1_delete_popup);//xml���� �̸�

		bundle = getIntent().getExtras();
		pet_name = bundle.getString("pet_name");
		year = bundle.getString("year");
		month = bundle.getString("month");
		day = bundle.getString("day");
		time = bundle.getString("time");
		detail = bundle.getString("detail");
		
		Button btn1 = (Button)findViewById(R.id.visitBtn);//�ٳ�ȹ�ư, ������ �߰�
		btn1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// delete operation
				if(ConnectDB.isNetworkAvailable()) {
					Dialog mProgress=new Dialog(ReservationView1DeletePopup.this,R.style.MyDialog);
					mProgress.setCancelable(true);
					mProgress.addContentView(new ProgressBar(ReservationView1DeletePopup.this),
											new LayoutParams(LayoutParams.WRAP_CONTENT,
															LayoutParams.WRAP_CONTENT));
					mProgress.show();
					try {
						ArrayList<String> result=ConnectDB.setVisitRsvHsp(id, pet_name, 
								year, month, day, time);
						
						
						if(result.get(0).equals("FIN"))
							Toast.makeText(getBaseContext(), "�������� �߰��Ǿ����ϴ�.\n���������� �����Ͽ��� Ȯ���ϼ���.", Toast.LENGTH_SHORT).show();
						else {
							if(result.get(0).equals("NO"))
								Toast.makeText(getBaseContext(), "ERROR : setVisitRsvHsp", Toast.LENGTH_SHORT).show();
						}
						finish();
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}		
					mProgress.dismiss();
					Intent intent = new Intent(getBaseContext(), ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
					finish();
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
							 Toast.LENGTH_SHORT).show();
			}	
        });
		
		Button btn2 = (Button)findViewById(R.id.deleteBtn);//�ȴٳ���� ����..(�������)
		btn2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(ConnectDB.isNetworkAvailable()) {
					Dialog mProgress=new Dialog(ReservationView1DeletePopup.this,R.style.MyDialog);
					mProgress.setCancelable(true);
					mProgress.addContentView(new ProgressBar(ReservationView1DeletePopup.this),
											new LayoutParams(LayoutParams.WRAP_CONTENT,
															LayoutParams.WRAP_CONTENT));
					try {
						ArrayList<String> result2=ConnectDB.deleteRsvHsp(id, pet_name, 
								year, month, day, time);
						
						if(result2.get(0).equals("FIN"))
							Toast.makeText(getBaseContext(), "������Ȳ���� ���� �Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
						else {
							if(result2.get(0).equals("NO"))
								Toast.makeText(getBaseContext(), "ERROR : setVisitRsvHsp", Toast.LENGTH_SHORT).show();
						}
						finish();
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}		
					mProgress.dismiss();
					Intent intent = new Intent(getBaseContext(), ReservationView.class);
					ConnectDB.deleteActListExceptMain();
					startActivity(intent);
				} /* connection Ȯ�� */
				else
					 Toast.makeText(getBaseContext(), "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", 
							 Toast.LENGTH_SHORT).show();
			}	
        });
		
		Button btn3 = (Button)findViewById(R.id.cancelBtn);//���
		btn3.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();		
			}	
        });
	}

	
}
