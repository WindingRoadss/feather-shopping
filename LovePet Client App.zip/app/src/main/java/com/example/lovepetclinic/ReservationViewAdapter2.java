package com.example.lovepetclinic;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;

import com.example.lovepetclinic.R;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ReservationViewAdapter2 extends BaseAdapter {
    Context ctx;
    LayoutInflater lInflater;
    ArrayList<ReservationViewItem2> objects;
    String id=ConnectDB.getId();
    Bundle bundle;

    ReservationViewAdapter2(Context context, ArrayList<ReservationViewItem2> products) {
        ctx = context;
        objects = products;
        lInflater = (LayoutInflater) ctx
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return objects.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = lInflater.inflate(R.layout.reservation_view_item2, parent, false);
        }
        final int po=position;
        final ReservationViewItem2 p = getProduct(position);
        String text=p.getIn_year()+"."+p.getIn_month()+"."+p.getIn_day()
        		+" ~ "+p.getOut_year()+"."+p.getOut_month()+"."+p.getOut_day()
        		+" "+"\n �� �̸� : "+p.getPet_name();
        if(p.getApproval().equals("0"))
        	text+=" - ���� ��";
        else if(p.getApproval().equals("1"))
        	text+=" - ���οϷ�";
        else if(p.getApproval().equals("2"))
        	text+=" - ���ΰź�";
        
        ((TextView) view.findViewById(R.id.reservationViewTextView)).setText(text);
        ((Button) view.findViewById(R.id.reservationViewDeleteButton))
		.setOnClickListener(new OnClickListener(){
				public void onClick(View v) {
					//progress
//					Dialog mProgress=new Dialog(ctx,R.style.MyDialog);
//					mProgress.setCancelable(true);
//					mProgress.addContentView(new ProgressBar(ctx),
//											new LayoutParams(LayoutParams.WRAP_CONTENT,
//															LayoutParams.WRAP_CONTENT));
//					mProgress.show();
//					////
//					try {
//						//pop up!!!!!!!!!!!
//						
//						ArrayList<String> result=ConnectDB.deleteRsvHtl(id, p.getPet_name(), p.getIn_year(),p.getIn_month()
//									,p.getIn_day(),p.getOut_year(),p.getOut_month(),p.getOut_day());
//						
//						if(result.get(0).equals("FIN"))
//							Toast.makeText(ctx, "�����Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
//						else 
//							Toast.makeText(ctx, "ERROR : deleteRsvHtl", Toast.LENGTH_SHORT).show();
//					} catch (ClientProtocolException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					} catch (IOException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					mProgress.dismiss();
					if(ConnectDB.isNetworkAvailable()) {
						bundle = new Bundle();
//						pet_name = bundle.getString("pet_name");
//						in_year = bundle.getString("in_year");
//						in_month = bundle.getString("in_month");
//						in_day = bundle.getString("in_day");
//						out_year = bundle.getString("out_year");
//						out_month = bundle.getString("out_month");
//						out_day = bundle.getString("out_day");
						bundle.putString("pet_name", p.getPet_name());
						bundle.putString("in_year", p.getIn_year());
						bundle.putString("in_month", p.getIn_month());
						bundle.putString("in_day", p.getIn_day());
						bundle.putString("out_year", p.getOut_year());
						bundle.putString("out_month", p.getOut_month());
						bundle.putString("out_day", p.getOut_day());
						Intent intent = new Intent(ctx, 
								ReservationView2DeletePopup.class);//LoginActivity.class);
						intent.putExtras(bundle);
						 ctx.startActivity(intent);
					} /* connection Ȯ�� */
					else
						Toast.makeText(ctx, "��Ʈ��ũ ���� ���¸� Ȯ���ϼ���", Toast.LENGTH_SHORT).show();
				}
		});

        return view;
    }

    ReservationViewItem2 getProduct(int position) {
        return ((ReservationViewItem2) getItem(position));
    }


}
